"""
Sample Data Generator for Smart Expense & Financial Analytics System.
Generates realistic 60+ expense records and 20+ income records with varied categories,
payment methods, dates, and intentional statistical outliers for testing.
"""

import os
import csv
import random
from datetime import datetime, timedelta

def generate_sample_datasets():
    data_dir = os.path.dirname(__file__)
    expenses_csv = os.path.join(data_dir, "sample_expenses.csv")
    income_csv = os.path.join(data_dir, "sample_income.csv")

    categories = ["Food", "Transportation", "Education", "Shopping", "Bills", "Healthcare", "Entertainment", "Rent", "Other"]
    payment_methods = ["UPI", "Credit Card", "Debit Card", "Cash", "Net Banking"]

    # Base start date: 90 days ago
    start_date = datetime.now() - timedelta(days=90)

    # 1. Expenses Data (65 records)
    expenses = []

    # Regular daily expenses
    food_items = [("Mess Fee", 2500), ("Groceries", 650), ("Lunch Canteen", 120), ("Café & Snacks", 250), ("Dinner with Friends", 850), ("Swiggy Order", 340)]
    transport_items = [("Auto Rickshaw", 60), ("Bus Pass", 450), ("Metro Card Top-up", 200), ("Petrol", 500), ("Cab Ride", 320)]
    edu_items = [("Textbooks", 1200), ("Stationery", 250), ("Photocopy & Printing", 80), ("Course Subscription", 999), ("Exam Fee", 1500)]
    shopping_items = [("T-Shirt & Jeans", 1800), ("Footwear", 1400), ("Backpack", 1100), ("Earbuds", 1500)]
    bills_items = [("Mobile Recharge", 299), ("Wi-Fi Internet", 799), ("Electricity Bill", 1450)]
    health_items = [("Medicines", 350), ("Doctor Consultation", 600), ("Protein Powder", 2400)]
    ent_items = [("Movie Tickets", 400), ("Gaming Subscription", 499), ("Weekend Trip", 2200)]
    rent_items = [("PG / Room Rent", 6500)]

    # Outliers to test anomaly detection (e.g. IQR, Z-Score, Isolation Forest)
    outlier_items = [
        ("Gaming Laptop Purchase", 58000, "Shopping", "Credit Card", "Special reward purchase"),
        ("Tuition & Exam Fee", 32000, "Education", "Net Banking", "Annual Course Fees"),
        ("Emergency Smartphone Repair", 12500, "Healthcare", "Credit Card", "Screen replacement")
    ]

    # Generate normal transactions
    random.seed(42) # For reproducible demonstration sample data
    for i in range(62):
        days_offset = random.randint(0, 88)
        tx_date = (start_date + timedelta(days=days_offset)).strftime("%Y-%m-%d")
        cat = random.choice(categories)

        if cat == "Food":
            desc, base_amt = random.choice(food_items)
            amt = round(base_amt * random.uniform(0.85, 1.25), 2)
        elif cat == "Transportation":
            desc, base_amt = random.choice(transport_items)
            amt = round(base_amt * random.uniform(0.9, 1.2), 2)
        elif cat == "Education":
            desc, base_amt = random.choice(edu_items)
            amt = round(base_amt * random.uniform(0.9, 1.3), 2)
        elif cat == "Shopping":
            desc, base_amt = random.choice(shopping_items)
            amt = round(base_amt * random.uniform(0.8, 1.4), 2)
        elif cat == "Bills":
            desc, base_amt = random.choice(bills_items)
            amt = round(base_amt * random.uniform(0.95, 1.05), 2)
        elif cat == "Healthcare":
            desc, base_amt = random.choice(health_items)
            amt = round(base_amt * random.uniform(0.9, 1.2), 2)
        elif cat == "Entertainment":
            desc, base_amt = random.choice(ent_items)
            amt = round(base_amt * random.uniform(0.8, 1.3), 2)
        elif cat == "Rent":
            desc, base_amt = random.choice(rent_items)
            amt = float(base_amt)
        else:
            desc, amt = "Miscellaneous Expense", round(random.uniform(100, 800), 2)

        pm = random.choice(payment_methods)
        notes = "Regular monthly expense" if random.random() > 0.5 else "Budget allocation"
        expenses.append({
            "date": tx_date,
            "amount": amt,
            "category": cat,
            "payment_method": pm,
            "description": desc,
            "notes": notes
        })

    # Append outliers
    for desc, amt, cat, pm, notes in outlier_items:
        tx_date = (start_date + timedelta(days=random.randint(10, 80))).strftime("%Y-%m-%d")
        expenses.append({
            "date": tx_date,
            "amount": amt,
            "category": cat,
            "payment_method": pm,
            "description": desc,
            "notes": notes
        })

    # Sort expenses by date
    expenses.sort(key=lambda x: x["date"])

    with open(expenses_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date", "amount", "category", "payment_method", "description", "notes"])
        writer.writeheader()
        writer.writerows(expenses)

    # 2. Income Data (22 records)
    income = []
    income_sources = ["Salary", "Allowance", "Freelance", "Scholarship", "Gift", "Other Income"]

    for month_offset in range(3):
        m_date = (start_date + timedelta(days=month_offset * 30 + 1)).strftime("%Y-%m-%d")
        income.append({"date": m_date, "amount": 15000.0, "source": "Allowance", "description": "Monthly Stipend"})
        income.append({"date": m_date, "amount": 8000.0, "source": "Scholarship", "description": "Merit Scholarship Installment"})
        income.append({"date": m_date, "amount": 6500.0, "source": "Freelance", "description": "Web Development Project"})

    # Additional freelance & gift income
    for i in range(13):
        days_offset = random.randint(0, 88)
        tx_date = (start_date + timedelta(days=days_offset)).strftime("%Y-%m-%d")
        src = random.choice(income_sources)
        amt = round(random.choice([1200, 2500, 4500, 8000, 3000, 5000]), 2)
        desc = f"Income from {src}"
        income.append({"date": tx_date, "amount": amt, "source": src, "description": desc})

    income.sort(key=lambda x: x["date"])

    with open(income_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date", "amount", "source", "description"])
        writer.writeheader()
        writer.writerows(income)

    print(f"Generated {len(expenses)} expense records and {len(income)} income records.")

if __name__ == "__main__":
    generate_sample_datasets()
