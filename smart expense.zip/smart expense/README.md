# Smart Expense & Financial Analytics System 💸

An end-to-end, professional local personal finance management and analytical application built in Python. The application enables users to log daily expenses, track income sources, monitor monthly category budgets, clean raw data, and perform interactive financial analytics.

---

## ✨ Key System Features

1. **📊 Executive Dashboard:** Real-time KPI metric cards (Total Income, Total Expenses, Current Net Balance, Monthly Expenses, Daily Average, Highest Category, Total Transactions, Net Savings Rate) with interactive Plotly charts.
2. **📑 Expense Management:** Add, edit, delete, search, filter (category, date range, payment method), sort, and validate expense transactions.
3. **💰 Income Management:** Log income entries (Salary, Allowance, Freelance, Scholarship, Gift) and compare cash flow balances.
4. **🎯 Category & Budget Management:** Set monthly budget limits per category with visual progress bars and overspend alerts (On Track, Warning > 80%, Exceeded > 100%).
5. **📈 Financial Analytics & Visualizations:** Plotly pie charts, daily trend lines, monthly cash flow bar charts, histograms, box plots, heatmaps, and Seaborn distribution plots.
6. **🧹 Data Preprocessing Pipeline:** Automated missing value imputation, duplicate transaction removal, category text title-case normalization, and before-and-after audit reports.
7. **📁 Data Import & Export (CSV):** Import expense and income CSV files with schema validation and duplicate checks; export filtered data to downloadable CSV reports.
8. **⚙️ System Settings & Data Seeding:** One-click demonstration dataset loader (65 expenses, 22 incomes), database wipe tools, and custom category management.

---

## 🛠️ Required Technology Stack

- **Core:** Python 3.11+
- **Data Manipulation:** Pandas, NumPy
- **Statistical Analysis:** SciPy (`scipy.stats`)
- **Database:** SQLite 3 (Parameterized local storage)
- **Frontend & Dashboard:** Streamlit
- **Visualizations:** Plotly Express, Plotly Graph Objects, Seaborn, Matplotlib

---

## 💻 Windows Installation & Setup Guide

### Step 1: Open Terminal & Navigate to Project Directory
```powershell
cd "c:\Users\Admin\smart expense"
```

### Step 2: Create Python Virtual Environment (Optional but Recommended)
```powershell
python -m venv venv
```

### Step 3: Activate Virtual Environment
```powershell
venv\Scripts\activate
```

### Step 4: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 5: Launch Streamlit Application
```powershell
streamlit run app.py
```

The application will launch automatically in your browser at `http://localhost:8501`.

---

## 🧪 Automated Testing

Run the unit test suite to verify database operations, data processing pipelines, and analytics calculations:

```powershell
python -m unittest tests/test_app.py
```

---

## 📂 Project Architecture & File Directory

```
smart_expense/
├── app.py                      # Main Streamlit Entry Point & Sidebar Navigation
├── requirements.txt            # Python Dependencies
├── README.md                   # Complete Documentation
│
├── database/
│   ├── db_manager.py           # Thread-safe SQLite Manager & Parameterized SQL
│   └── schema.sql              # Database Tables DDL Script
│
├── modules/
│   ├── expense_manager.py      # Expense CRUD, Input Validation, Filters & Search
│   ├── income_manager.py       # Income Record Operations
│   ├── category_manager.py     # Default & Custom Category Management
│   ├── budget_manager.py       # Monthly Category Budgets & Utilization Status
│   ├── data_cleaning.py        # Preprocessing Pipeline (Missing, Duplicates, Normalization)
│   └── reports.py              # CSV Import/Export Engine & Validation
│
├── analytics/
│   ├── calculations.py         # KPI Metric Engine & Date Bounds
│   └── visualizations.py       # Plotly & Seaborn Chart Generators
│
├── pages_custom/               # Structured Streamlit Views
│   ├── dashboard_view.py       # Executive Overview & Financial KPIs
│   ├── expenses_view.py        # Record, Search, Edit & Delete Expenses
│   ├── income_view.py          # Income Management
│   ├── budgets_view.py         # Category Budget Progress & Alerts
│   ├── analytics_view.py       # Visual Spending Trends & Heatmaps
│   ├── cleaning_view.py        # Data Preprocessing & Audit Logs
│   ├── import_export_view.py   # CSV Data I/O & Downloadable Templates
│   └── settings_view.py        # Sample Data Seeding & System Admin
│
├── data/                       # Sample CSV Datasets & Generator Script
│   ├── generate_sample_data.py # Sample Data Generator
│   ├── sample_expenses.csv     # 65 Sample Expenses
│   └── sample_income.csv       # 22 Sample Incomes
│
└── tests/
    └── test_app.py             # Pytest / Unittest Suite (100% Pass Rate)
```

---

## 🔒 Security & Data Privacy

- Uses 100% local SQLite database storage.
- Requires no real bank credentials, cloud APIs, or paid third-party tokens.
- Parameterized SQL execution prevents SQL injection.
