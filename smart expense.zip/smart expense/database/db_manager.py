"""
Database Manager for Smart Expense & Financial Analytics System.
Handles SQLite connections, schema initialization, parameterized queries, and thread-safe operations.
"""

import os
import sqlite3
import pandas as pd
from typing import List, Dict, Any, Tuple, Optional

# Default Database Path
DB_FILE = os.path.join(os.path.dirname(__file__), "smart_expense.db")
SCHEMA_FILE = os.path.join(os.path.dirname(__file__), "schema.sql")

class DatabaseManager:
    def __init__(self, db_path: str = DB_FILE):
        self.db_path = db_path
        self._init_db()

    def get_connection(self) -> sqlite3.Connection:
        """Create and return a database connection with Row factory enabled."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Initialize database schema if tables do not exist."""
        if os.path.exists(SCHEMA_FILE):
            with open(SCHEMA_FILE, "r", encoding="utf-8") as f:
                schema_sql = f.read()
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.executescript(schema_sql)
                conn.commit()
        else:
            # Fallback inline schema creation
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    category_type TEXT NOT NULL DEFAULT 'Expense'
                );
                """)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    amount REAL NOT NULL CHECK(amount > 0),
                    category TEXT NOT NULL,
                    payment_method TEXT NOT NULL,
                    description TEXT,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS income (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    amount REAL NOT NULL CHECK(amount > 0),
                    source TEXT NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS budgets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,
                    monthly_limit REAL NOT NULL CHECK(monthly_limit >= 0),
                    month INTEGER NOT NULL,
                    year INTEGER NOT NULL,
                    UNIQUE(category, month, year)
                );
                """)
                conn.commit()

    def execute_query(self, query: str, params: Tuple = ()) -> int:
        """Execute parameterized INSERT, UPDATE, DELETE query. Returns affected row count or lastrowid."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            return cursor.lastrowid

    def fetch_all(self, query: str, params: Tuple = ()) -> List[Dict[str, Any]]:
        """Fetch query results as list of dictionaries."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def fetch_one(self, query: str, params: Tuple = ()) -> Optional[Dict[str, Any]]:
        """Fetch single query result as dictionary."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return dict(row) if row else None

    def fetch_dataframe(self, query: str, params: Tuple = ()) -> pd.DataFrame:
        """Fetch query results directly as Pandas DataFrame."""
        with self.get_connection() as conn:
            df = pd.read_sql_query(query, conn, params=params)
            return df

    def clear_database(self):
        """Reset and wipe all transactional data for fresh imports/testing."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM expenses;")
            cursor.execute("DELETE FROM income;")
            cursor.execute("DELETE FROM budgets;")
            conn.commit()

# Singleton DB instance
db = DatabaseManager()
