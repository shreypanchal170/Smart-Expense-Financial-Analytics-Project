-- SQLite Database Schema for Smart Expense & Financial Analytics System

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category_type TEXT NOT NULL DEFAULT 'Expense'
);

-- Expenses Table
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    category TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    description TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Income Table
CREATE TABLE IF NOT EXISTS income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    source TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Budgets Table
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    monthly_limit REAL NOT NULL CHECK(monthly_limit >= 0),
    month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
    year INTEGER NOT NULL CHECK(year >= 2000),
    UNIQUE(category, month, year)
);

-- Default Category Seeds
INSERT OR IGNORE INTO categories (name, category_type) VALUES
('Food', 'Expense'),
('Transportation', 'Expense'),
('Education', 'Expense'),
('Shopping', 'Expense'),
('Bills', 'Expense'),
('Healthcare', 'Expense'),
('Entertainment', 'Expense'),
('Rent', 'Expense'),
('Other', 'Expense'),
('Salary', 'Income'),
('Allowance', 'Income'),
('Freelance', 'Income'),
('Scholarship', 'Income'),
('Gift', 'Income'),
('Other Income', 'Income');
