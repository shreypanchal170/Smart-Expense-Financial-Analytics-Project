"""
Financial Analytics & KPI Calculation Module for Smart Expense System.
Computes summary metrics, cash flow statistics, and date-range aggregated totals.
"""

from datetime import datetime, timedelta
import pandas as pd
from typing import Dict, Any, Optional, Tuple
from database.db_manager import db
from modules.anomaly_detection import detect_outliers_iqr

def get_date_range_bounds(filter_type: str = "This Month", custom_start: Optional[str] = None, custom_end: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """Convert human-readable date filter presets into YYYY-MM-DD date bounds."""
    today = datetime.now().date()

    if filter_type == "Today":
        start = today.strftime("%Y-%m-%d")
        end = start
    elif filter_type == "This Week":
        start = (today - timedelta(days=today.weekday())).strftime("%Y-%m-%d")
        end = today.strftime("%Y-%m-%d")
    elif filter_type == "This Month":
        start = today.replace(day=1).strftime("%Y-%m-%d")
        end = today.strftime("%Y-%m-%d")
    elif filter_type == "Last Month":
        first_of_this_month = today.replace(day=1)
        last_day_last_month = first_of_this_month - timedelta(days=1)
        start = last_day_last_month.replace(day=1).strftime("%Y-%m-%d")
        end = last_day_last_month.strftime("%Y-%m-%d")
    elif filter_type == "Last 90 Days":
        start = (today - timedelta(days=90)).strftime("%Y-%m-%d")
        end = today.strftime("%Y-%m-%d")
    elif filter_type == "Custom" and custom_start and custom_end:
        start = custom_start
        end = custom_end
    else:
        # All Time
        start = None
        end = None

    return start, end

def calculate_dashboard_kpis(start_date: Optional[str] = None, end_date: Optional[str] = None) -> Dict[str, Any]:
    """
    Calculate executive KPI metrics for the Dashboard:
    - Total Income
    - Total Expenses
    - Net Balance
    - Monthly Expenses
    - Daily Average Expense
    - Highest Spending Category
    - Transaction Count
    - Unusual Expense Count (IQR)
    """
    # 1. Fetch Expenses in Date Range
    exp_conds = ["1=1"]
    exp_params = []
    if start_date:
        exp_conds.append("date >= ?")
        exp_params.append(start_date)
    if end_date:
        exp_conds.append("date <= ?")
        exp_params.append(end_date)

    exp_query = f"SELECT * FROM expenses WHERE {' AND '.join(exp_conds)}"
    exp_df = db.fetch_dataframe(exp_query, tuple(exp_params))

    # 2. Fetch Income in Date Range
    inc_conds = ["1=1"]
    inc_params = []
    if start_date:
        inc_conds.append("date >= ?")
        inc_params.append(start_date)
    if end_date:
        inc_conds.append("date <= ?")
        inc_params.append(end_date)

    inc_query = f"SELECT * FROM income WHERE {' AND '.join(inc_conds)}"
    inc_df = db.fetch_dataframe(inc_query, tuple(inc_params))

    total_expenses = float(exp_df["amount"].sum()) if not exp_df.empty else 0.0
    total_income = float(inc_df["amount"].sum()) if not inc_df.empty else 0.0
    current_balance = total_income - total_expenses
    tx_count = len(exp_df)

    # Highest spending category
    highest_cat = "N/A"
    highest_cat_amount = 0.0
    if not exp_df.empty:
        cat_sums = exp_df.groupby("category")["amount"].sum()
        highest_cat = str(cat_sums.idxmax())
        highest_cat_amount = float(cat_sums.max())

    # Daily average expense calculation
    daily_avg = 0.0
    if not exp_df.empty and "date" in exp_df.columns:
        dates = pd.to_datetime(exp_df["date"]).dt.date
        num_active_days = len(dates.unique())
        daily_avg = total_expenses / num_active_days if num_active_days > 0 else total_expenses

    # Monthly expense sum for current month
    current_month_str = datetime.now().strftime("%Y-%m")
    monthly_exp_df = db.fetch_dataframe("SELECT SUM(amount) as total FROM expenses WHERE strftime('%Y-%m', date) = ?", (current_month_str,))
    monthly_expense = float(monthly_exp_df["total"].iloc[0]) if not monthly_exp_df.empty and pd.notna(monthly_exp_df["total"].iloc[0]) else 0.0

    # Unusual expense count via IQR
    unusual_count = 0
    if not exp_df.empty and len(exp_df) >= 4:
        anomaly_df = detect_outliers_iqr(exp_df, column="amount", k=1.5)
        unusual_count = int(anomaly_df["is_anomaly"].sum())

    return {
        "total_income": total_income,
        "total_expenses": total_expenses,
        "current_balance": current_balance,
        "monthly_expense": monthly_expense,
        "daily_avg": daily_avg,
        "highest_category": highest_cat,
        "highest_category_amount": highest_cat_amount,
        "transaction_count": tx_count,
        "unusual_count": unusual_count
    }
