"""
Data Visualization Module for Smart Expense & Financial Analytics System.
Implements data visualizations with Plotly Express, Plotly Graph Objects,
Matplotlib, and Seaborn.
"""

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Optional, Tuple
from modules.statistics_analysis import generate_normal_pdf_fit

# Set default Seaborn & Matplotlib theme for clean academic plots
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams.update({'font.sans-serif': 'Arial', 'font.family': 'sans-serif'})

DARK_THEME_LAYOUT = dict(
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(0,0,0,0)',
    font=dict(color='#E0E6ED', size=12),
    margin=dict(l=40, r=40, t=50, b=40)
)

def create_category_pie_chart(df: pd.DataFrame) -> go.Figure:
    """1. Pie Chart: Expense distribution by category (Plotly)."""
    if df.empty or "category" not in df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No Expense Data Available", showarrow=False, font=dict(size=16, color="#888"))
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    cat_df = df.groupby("category")["amount"].sum().reset_index()
    fig = px.pie(
        cat_df,
        values="amount",
        names="category",
        title="Expense Distribution by Category",
        hole=0.4,
        color_discrete_sequence=px.colors.qualitative.Pastel
    )
    fig.update_traces(textposition='inside', textinfo='percent+label', hovertemplate='<b>%{label}</b><br>Amount: ₹%{value:,.2f}<br>Share: %{percent}')
    fig.update_layout(**DARK_THEME_LAYOUT)
    return fig

def create_daily_trend_line_chart(df: pd.DataFrame) -> go.Figure:
    """3. Line Chart: Daily expense trend over time (Plotly)."""
    if df.empty or "date" not in df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No Expense Data Available", showarrow=False)
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    daily_df = df.groupby("date")["amount"].sum().reset_index().sort_values("date")
    daily_df["cumulative"] = daily_df["amount"].cumsum()

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=daily_df["date"],
        y=daily_df["amount"],
        mode='lines+markers',
        name='Daily Spending',
        line=dict(color='#00D2FF', width=3),
        marker=dict(size=6)
    ))
    fig.add_trace(go.Scatter(
        x=daily_df["date"],
        y=daily_df["cumulative"],
        mode='lines',
        name='Cumulative Spend',
        line=dict(color='#00F2FE', width=2, dash='dash')
    ))

    fig.update_layout(
        title="Daily Expense Trend & Cumulative Growth",
        xaxis_title="Date",
        yaxis_title="Amount (₹)",
        hovermode="x unified",
        **DARK_THEME_LAYOUT
    )
    return fig

def create_income_vs_expense_bar_chart(exp_df: pd.DataFrame, inc_df: pd.DataFrame) -> go.Figure:
    """4. Bar Chart: Monthly Income vs Expense comparison (Plotly)."""
    exp_monthly = pd.DataFrame(columns=["month", "Expenses"])
    inc_monthly = pd.DataFrame(columns=["month", "Income"])

    if exp_df is not None and not exp_df.empty and "date" in exp_df.columns:
        exp_temp = exp_df.copy()
        exp_temp["month"] = pd.to_datetime(exp_temp["date"]).dt.strftime("%Y-%m")
        exp_monthly = exp_temp.groupby("month")["amount"].sum().reset_index().rename(columns={"amount": "Expenses"})

    if inc_df is not None and not inc_df.empty and "date" in inc_df.columns:
        inc_temp = inc_df.copy()
        inc_temp["month"] = pd.to_datetime(inc_temp["date"]).dt.strftime("%Y-%m")
        inc_monthly = inc_temp.groupby("month")["amount"].sum().reset_index().rename(columns={"amount": "Income"})

    if exp_monthly.empty and inc_monthly.empty:
        fig = go.Figure()
        fig.add_annotation(text="No Data Available for Income/Expense Comparison", showarrow=False)
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    merged = pd.merge(inc_monthly, exp_monthly, on="month", how="outer").fillna(0).sort_values("month")

    fig = go.Figure()
    fig.add_trace(go.Bar(x=merged["month"], y=merged["Income"], name="Income", marker_color="#00E676"))
    fig.add_trace(go.Bar(x=merged["month"], y=merged["Expenses"], name="Expenses", marker_color="#FF5252"))

    fig.update_layout(
        title="Monthly Cash Flow: Income vs Expense",
        barmode="group",
        xaxis_title="Month",
        yaxis_title="Amount (₹)",
        **DARK_THEME_LAYOUT
    )
    return fig

def create_amount_histogram(df: pd.DataFrame) -> go.Figure:
    """5. Histogram: Expense amount distribution (Plotly)."""
    if df.empty or "amount" not in df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No Data Available", showarrow=False)
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    fig = px.histogram(
        df,
        x="amount",
        nbins=25,
        title="Expense Amount Distribution (Histogram)",
        labels={"amount": "Expense Amount (₹)"},
        color_discrete_sequence=["#7C4DFF"]
    )
    fig.update_layout(**DARK_THEME_LAYOUT)
    return fig

def create_box_plot_outliers(df: pd.DataFrame) -> go.Figure:
    """6. Box Plot: Outlier analysis by category (Plotly)."""
    if df.empty or "category" not in df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No Data Available", showarrow=False)
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    fig = px.box(
        df,
        x="category",
        y="amount",
        color="category",
        title="Category-wise Expense Box Plot (Statistical Outlier Spread)",
        points="all",
        labels={"amount": "Amount (₹)", "category": "Category"}
    )
    fig.update_layout(**DARK_THEME_LAYOUT)
    return fig

def create_spending_heatmap(df: pd.DataFrame) -> go.Figure:
    """7. Heatmap: Spending density by Day of Week vs Category (Plotly)."""
    if df.empty or "date" not in df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No Data Available for Heatmap", showarrow=False)
        fig.update_layout(**DARK_THEME_LAYOUT)
        return fig

    temp_df = df.copy()
    temp_df["day_name"] = pd.to_datetime(temp_df["date"]).dt.day_name()
    days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

    pivot = temp_df.pivot_table(index="category", columns="day_name", values="amount", aggfunc="sum").fillna(0)
    pivot = pivot.reindex(columns=[d for d in days_order if d in pivot.columns])

    fig = px.imshow(
        pivot,
        labels=dict(x="Day of Week", y="Category", color="Total Spent (₹)"),
        x=pivot.columns,
        y=pivot.index,
        title="Spending Density Heatmap (Category vs Day of Week)",
        color_continuous_scale="Purples"
    )
    fig.update_layout(**DARK_THEME_LAYOUT)
    return fig

def generate_seaborn_statistical_plots(df: pd.DataFrame) -> Tuple[plt.Figure, plt.Figure]:
    """
    Generate Matplotlib/Seaborn figures for statistical presentation.
    Returns: (Distplot with Normal PDF curve, Category Bar Chart)
    """
    if df.empty or "amount" not in df.columns:
        fig1, ax1 = plt.subplots(figsize=(6, 4))
        ax1.text(0.5, 0.5, "No Data", ha='center', va='center')
        fig2, ax2 = plt.subplots(figsize=(6, 4))
        ax2.text(0.5, 0.5, "No Data", ha='center', va='center')
        return fig1, fig2

    # 1. Distribution & Normal Curve Fitting
    fig1, ax1 = plt.subplots(figsize=(7, 4.5))
    sns.histplot(df["amount"], kde=True, stat="density", color="teal", ax=ax1, bins=20)
    
    # Fit theoretical normal curve
    x_pdf, y_pdf, mu, sigma = generate_normal_pdf_fit(df["amount"])
    if len(x_pdf) > 0:
        ax1.plot(x_pdf, y_pdf, 'r--', linewidth=2, label=f'Normal Fit (μ={mu:.1f}, σ={sigma:.1f})')
        ax1.legend()
        
    ax1.set_title("Empirical Expense Distribution vs Theoretical Normal Fit", fontsize=11, fontweight='bold')
    ax1.set_xlabel("Amount (₹)")
    ax1.set_ylabel("Density")
    fig1.tight_layout()

    # 2. Category Summary Bar Chart
    fig2, ax2 = plt.subplots(figsize=(7, 4.5))
    cat_summary = df.groupby("category")["amount"].sum().sort_values(ascending=False).reset_index()
    sns.barplot(data=cat_summary, x="amount", y="category", palette="viridis", ax=ax2)
    ax2.set_title("Total Spending by Category (Seaborn)", fontsize=11, fontweight='bold')
    ax2.set_xlabel("Total Amount (₹)")
    ax2.set_ylabel("Category")
    fig2.tight_layout()

    return fig1, fig2
