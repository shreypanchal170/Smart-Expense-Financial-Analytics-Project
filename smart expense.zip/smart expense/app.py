"""
Main Entry Point for Smart Expense & Financial Analytics System.
"""

import os
import streamlit as st

# Set page config FIRST before any other Streamlit commands
st.set_page_config(
    page_title="Smart Expense & Financial Analytics System",
    page_icon="💸",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (Vanilla CSS)
st.markdown("""
<style>
    /* Google Fonts Import */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    /* Metric Cards Styling */
    div[data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%);
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 18px 22px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    div[data-testid="stMetric"]:hover {
        transform: translateY(-2px);
        border-color: rgba(0, 210, 255, 0.4);
    }
    div[data-testid="stMetricLabel"] {
        font-weight: 500;
        font-size: 0.88rem;
        color: #A0AEC0;
    }
    div[data-testid="stMetricValue"] {
        font-weight: 700;
        font-size: 1.4rem;
    }

    /* Primary Accent Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #0F172A;
        border-right: 1px solid #1E293B;
    }
</style>
""", unsafe_allow_html=True)

# Database Auto-Seeding on initial startup if empty
from database.db_manager import db
from data.generate_sample_data import generate_sample_datasets
from modules.reports import import_expenses_from_csv, import_income_from_csv

def auto_seed_if_empty():
    check_df = db.fetch_dataframe("SELECT COUNT(*) as count FROM expenses")
    if check_df.empty or check_df["count"].iloc[0] == 0:
        data_dir = os.path.join(os.path.dirname(__file__), "data")
        exp_csv = os.path.join(data_dir, "sample_expenses.csv")
        inc_csv = os.path.join(data_dir, "sample_income.csv")

        if not os.path.exists(exp_csv) or not os.path.exists(inc_csv):
            generate_sample_datasets()

        with open(exp_csv, "rb") as f_exp:
            import_expenses_from_csv(f_exp)
        with open(inc_csv, "rb") as f_inc:
            import_income_from_csv(f_inc)

auto_seed_if_empty()

# Sidebar Navigation
with st.sidebar:
    st.markdown("<h1 style='font-size: 2.5rem; margin-bottom: -15px;'>💸</h1>", unsafe_allow_html=True)
    st.title("Smart Expense Analytics")
    st.caption("Personal Finance & Analytics Platform")

    st.markdown("---")

    page_choice = st.radio(
        "Navigation",
        [
            "📊 Dashboard",
            "📑 Manage Expenses",
            "💰 Income Management",
            "🎯 Budget Management",
            "📈 Financial Analytics",
            "🧹 Data Cleaning Pipeline",
            "📁 Import / Export CSV",
            "⚙️ Settings & DB Admin"
        ],
        index=0
    )

# Route to Page Views
from pages_custom.dashboard_view import render_dashboard_page
from pages_custom.expenses_view import render_expenses_page
from pages_custom.income_view import render_income_page
from pages_custom.budgets_view import render_budgets_page
from pages_custom.analytics_view import render_analytics_page
from pages_custom.cleaning_view import render_cleaning_page
from pages_custom.import_export_view import render_import_export_page
from pages_custom.settings_view import render_settings_page

if page_choice == "📊 Dashboard":
    render_dashboard_page()
elif page_choice == "📑 Manage Expenses":
    render_expenses_page()
elif page_choice == "💰 Income Management":
    render_income_page()
elif page_choice == "🎯 Budget Management":
    render_budgets_page()
elif page_choice == "📈 Financial Analytics":
    render_analytics_page()
elif page_choice == "🧹 Data Cleaning Pipeline":
    render_cleaning_page()
elif page_choice == "📁 Import / Export CSV":
    render_import_export_page()
elif page_choice == "⚙️ Settings & DB Admin":
    render_settings_page()
