"""
Automated Unit Tests for Smart Expense & Financial Analytics System.
Uses Python's unittest module to test DB initialization, CRUD operations, input validation,
data cleaning, statistical calculations, outlier detection, and CSV import/export.
"""

import os
import unittest
import pandas as pd
from database.db_manager import db, DatabaseManager
from modules.expense_manager import add_expense, update_expense, delete_expense, get_expense_by_id, validate_expense_input, get_expenses_df
from modules.income_manager import add_income, update_income, delete_income, validate_income_input, get_income_df
from modules.budget_manager import set_budget, get_budget_status
from modules.data_cleaning import DataCleaner
from modules.statistics_analysis import calculate_descriptive_stats, calculate_confidence_interval, run_one_sample_ttest
from modules.anomaly_detection import detect_outliers_iqr, detect_outliers_zscore, detect_outliers_isolation_forest
from analytics.calculations import calculate_dashboard_kpis

TEST_DB_FILE = os.path.join(os.path.dirname(__file__), "test_smart_expense.db")

class TestSmartExpenseSystem(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """Set up temporary test database before running unit tests."""
        db.db_path = TEST_DB_FILE
        db._init_db()

    @classmethod
    def tearDownClass(cls):
        """Clean up test database file after completion."""
        if os.path.exists(TEST_DB_FILE):
            try:
                os.remove(TEST_DB_FILE)
            except Exception:
                pass

    def setUp(self):
        """Clear database before each test method."""
        db.clear_database()

    # 1. Input Validation Tests
    def test_expense_input_validation(self):
        valid, msg = validate_expense_input(100.0, "2026-09-01", "Food", "UPI")
        self.assertTrue(valid)

        # Reject negative amount
        valid_neg, msg_neg = validate_expense_input(-50.0, "2026-09-01", "Food", "UPI")
        self.assertFalse(valid_neg)

        # Reject invalid date
        valid_date, msg_date = validate_expense_input(100.0, "invalid-date", "Food", "UPI")
        self.assertFalse(valid_date)

    # 2. Expense CRUD Operations
    def test_expense_crud_workflow(self):
        # Create
        ok, msg = add_expense("2026-09-01", 350.0, "Food", "UPI", "Canteen Lunch", "Student note")
        self.assertTrue(ok)

        df = get_expenses_df()
        self.assertEqual(len(df), 1)
        exp_id = int(df.iloc[0]["id"])

        # Read
        record = get_expense_by_id(exp_id)
        self.assertIsNotNone(record)
        self.assertEqual(record["amount"], 350.0)

        # Update
        ok_up, msg_up = update_expense(exp_id, "2026-09-01", 450.0, "Food", "UPI", "Updated Lunch", "Updated Note")
        self.assertTrue(ok_up)
        updated_rec = get_expense_by_id(exp_id)
        self.assertEqual(updated_rec["amount"], 450.0)

        # Delete
        ok_del, msg_del = delete_expense(exp_id)
        self.assertTrue(ok_del)
        self.assertIsNone(get_expense_by_id(exp_id))

    # 3. Income CRUD Operations
    def test_income_crud(self):
        ok, msg = add_income("2026-09-01", 15000.0, "Allowance", "Parental stipend")
        self.assertTrue(ok)

        inc_df = get_income_df()
        self.assertEqual(len(inc_df), 1)
        self.assertEqual(inc_df.iloc[0]["amount"], 15000.0)

    # 4. Budget Tracking Test
    def test_budget_utilization(self):
        set_budget("Food", 2000.0, 9, 2026)
        add_expense("2026-09-10", 1500.0, "Food", "UPI", "Groceries")

        status_list = get_budget_status(9, 2026)
        self.assertEqual(len(status_list), 1)
        food_status = status_list[0]
        self.assertEqual(food_status["spent"], 1500.0)
        self.assertEqual(food_status["remaining"], 500.0)
        self.assertEqual(food_status["utilization_pct"], 75.0)

    # 5. Data Cleaning Pipeline Test
    def test_data_cleaner_pipeline(self):
        raw_data = pd.DataFrame([
            {"date": "2026-09-01", "amount": 100.0, "category": "food", "description": "Lunch"},
            {"date": "2026-09-01", "amount": 100.0, "category": "food", "description": "Lunch"}, # Duplicate
            {"date": "invalid", "amount": 50.0, "category": "Bills", "description": "Invalid Date"},
            {"date": "2026-09-02", "amount": -20.0, "category": "Shopping", "description": "Negative Amount"}
        ])

        cleaner = DataCleaner(raw_data)
        cleaned_df, summary = cleaner.clean_pipeline(drop_duplicates=True, fill_missing=True, normalize_categories=True)

        self.assertEqual(len(cleaned_df), 1) # Only 1 valid record should remain
        self.assertEqual(cleaned_df.iloc[0]["category"], "Food") # Title case normalization

    # 6. Statistical Analysis Test
    def test_descriptive_and_inferential_stats(self):
        data = pd.DataFrame({"amount": [100.0, 150.0, 200.0, 250.0, 300.0, 5000.0]}) # Include outlier 5000
        desc = calculate_descriptive_stats(data, column="amount")

        self.assertEqual(desc["count"], 6)
        self.assertEqual(desc["min"], 100.0)
        self.assertEqual(desc["max"], 5000.0)

        ci = calculate_confidence_interval(data["amount"], confidence=0.95)
        self.assertIn("ci_lower", ci)
        self.assertIn("ci_upper", ci)

        ttest = run_one_sample_ttest(data["amount"], pop_mean=200.0)
        self.assertIn("p_value", ttest)

    # 7. Unusual Expense Detection (IQR, Z-Score, Isolation Forest)
    def test_outlier_detection_methods(self):
        data = pd.DataFrame({
            "id": list(range(1, 11)),
            "date": ["2026-09-01"] * 10,
            "amount": [100.0, 110.0, 105.0, 120.0, 115.0, 95.0, 100.0, 105.0, 110.0, 50000.0], # 50000 is obvious outlier
            "category": ["Food"] * 9 + ["Shopping"],
            "payment_method": ["UPI"] * 10,
            "description": ["Item"] * 10
        })

        # IQR
        iqr_df = detect_outliers_iqr(data, column="amount", k=1.5)
        self.assertTrue(iqr_df.iloc[-1]["is_anomaly"])

        # Z-Score
        z_df = detect_outliers_zscore(data, column="amount", threshold=2.0)
        self.assertTrue(z_df.iloc[-1]["is_anomaly"])

        # Isolation Forest
        iso_df = detect_outliers_isolation_forest(data, column="amount", contamination=0.1)
        self.assertTrue(iso_df.iloc[-1]["is_anomaly"])

    # 8. Visualizations Edge Cases
    def test_income_vs_expense_bar_chart_edge_cases(self):
        from analytics.visualizations import create_income_vs_expense_bar_chart
        exp_df = pd.DataFrame([{"date": "2026-09-01", "amount": 100.0}])
        empty_df = pd.DataFrame()

        # One empty DataFrame should not throw KeyError: 'month'
        fig1 = create_income_vs_expense_bar_chart(exp_df, empty_df)
        self.assertIsNotNone(fig1)

        fig2 = create_income_vs_expense_bar_chart(empty_df, exp_df)
        self.assertIsNotNone(fig2)

        # Both empty
        fig3 = create_income_vs_expense_bar_chart(empty_df, empty_df)
        self.assertIsNotNone(fig3)

if __name__ == "__main__":
    unittest.main()
