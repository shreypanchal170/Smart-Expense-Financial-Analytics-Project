# Smart Expense & Financial Analytics System 💸
## Comprehensive Code Report, Imported Libraries Reference & Technical Architecture Guide

---

## 📑 Table of Contents
1. [Executive System Overview](#1-executive-system-overview)
2. [Imported Python Libraries Overview & Usage Descriptions](#2-imported-python-libraries-overview--usage-descriptions)
3. [Third-Party Python Libraries & Used Functions Matrix](#3-third-party-python-libraries--used-functions-matrix)
4. [System Architecture & Working Data Flow](#4-system-architecture--working-data-flow)
5. [Complete Data Visualizations & Graphs Catalog](#5-complete-data-visualizations--graphs-catalog)
6. [Database Schema & Persistence Layer](#6-database-schema--persistence-layer)
7. [Module-by-Module Code Breakdown](#7-module-by-module-code-breakdown)
8. [Statistical & Machine Learning Algorithms](#8-statistical--machine-learning-algorithms)
9. [System Verification & Pass Rate](#9-system-verification--pass-rate)

---

## 1. Executive System Overview

The **Smart Expense & Financial Analytics System** is a professional local personal finance management and data analytics platform written in Python 3.11+. The system allows users to track expenses and income, manage category budgets, run automated data cleaning pipelines, analyze financial trends using interactive charts, detect financial anomalies using statistical/machine learning techniques, and import/export structured CSV reports.

---

## 2. Imported Python Libraries Overview & Usage Descriptions

### 1. Streamlit (`import streamlit as st`)
- **Description**: An open-source Python framework for rapidly building custom interactive web applications.
- **Where Used**: `app.py` and all view modules in `pages_custom/`.
- **Application Role & Overview**:
  - Controls the main web layout, dark theme styling (`#0F172A`), and sidebar radio menu routing across 8 page views.
  - Displays dynamic KPI metric cards, data tables, select boxes, date pickers, input forms, and status alert banners (success, info, warning, error).
  - Manages reactive session state, button clicks, file uploaders, CSV report downloads, and triggers application reruns (`st.rerun()`).

### 2. Pandas (`import pandas as pd`)
- **Description**: High-performance data manipulation and DataFrame analysis library.
- **Where Used**: `database/db_manager.py`, `analytics/calculations.py`, `analytics/visualizations.py`, `modules/expense_manager.py`, `modules/income_manager.py`, `modules/budget_manager.py`, `modules/data_cleaning.py`, `modules/reports.py`, `modules/anomaly_detection.py`, `modules/statistics_analysis.py`, `tests/test_app.py`.
- **Application Role & Overview**:
  - Executes SQL queries directly into structured DataFrames using `pd.read_sql_query()`.
  - Computes group-by aggregations (`df.groupby()`), cumulative spending sums (`cumsum()`), and 2D matrix pivot tables.
  - Powers the 6-stage automated Data Cleaning pipeline (missing value imputation, category Title Case normalization, date parsing, duplicate dropping).

### 3. NumPy (`import numpy as np`)
- **Description**: Vectorized mathematical and numerical computing library.
- **Where Used**: `modules/anomaly_detection.py`, `modules/statistics_analysis.py`, `modules/data_cleaning.py`, `analytics/visualizations.py`.
- **Application Role & Overview**:
  - Provides conditional array logic (`np.where()`) to assign anomaly status flags and explanation strings.
  - Generates linear point ranges (`np.linspace()`) for normal probability distribution curve fitting.
  - Handles missing numerical values and NaN replacements (`np.nan`) during data preprocessing.

### 4. Plotly Express & Plotly Graph Objects (`import plotly.express as px`, `import plotly.graph_objects as go`)
- **Description**: Declarative interactive web graphics library for high-definition chart rendering.
- **Where Used**: `analytics/visualizations.py`, `pages_custom/dashboard_view.py`, `pages_custom/analytics_view.py`.
- **Application Role & Overview**:
  - Renders Donut Pie charts (`px.pie`), Histograms (`px.histogram`), Box plots (`px.box`), and 2D Heatmaps (`px.imshow`).
  - Constructs multi-trace line charts (`go.Scatter`) comparing daily spending against cumulative financial growth.
  - Renders side-by-side grouped bar charts (`go.Bar`) for monthly cash flow comparisons (Income vs Expense).

### 5. SciPy Stats (`import scipy.stats as stats`)
- **Description**: Open-source scientific computing and statistical inference package.
- **Where Used**: `modules/statistics_analysis.py`, `analytics/visualizations.py`.
- **Application Role & Overview**:
  - Computes Standard Error of the Mean (`stats.sem`) and Student's t-distribution critical values (`stats.t.ppf`) for 95% Confidence Intervals.
  - Runs One-Sample Hypothesis t-tests (`stats.ttest_1samp`) to evaluate spending against benchmark targets.
  - Generates theoretical Gaussian Normal Probability Density Function curves (`stats.norm.pdf`).

### 6. Seaborn (`import seaborn as sns`)
- **Description**: High-level statistical visualization library built on top of Matplotlib.
- **Where Used**: `analytics/visualizations.py`.
- **Application Role & Overview**:
  - Plots empirical expense Kernel Density Estimation (KDE) distribution curves (`sns.histplot`).
  - Renders horizontal category spending bar charts styled with curated color palettes (`sns.barplot`).

### 7. Matplotlib Pyplot (`import matplotlib.pyplot as plt`)
- **Description**: Fundamental 2D plotting library providing canvas figure controls.
- **Where Used**: `analytics/visualizations.py`.
- **Application Role & Overview**:
  - Creates figure and axis handles (`plt.subplots()`) for static statistical plots.
  - Renders Seaborn visual objects directly inside Streamlit using `st.pyplot(fig)`.

### 8. Scikit-Learn Isolation Forest (`from sklearn.ensemble import IsolationForest`)
- **Description**: Machine learning ensemble classifier for unsupervised anomaly detection.
- **Where Used**: `modules/anomaly_detection.py`.
- **Application Role & Overview**:
  - Trains decision tree forests to isolate unusual expense transactions based on tree depth path lengths.
  - Predicts outlier status (`-1` for anomaly, `1` for normal) and outputs decision boundary anomaly scores.

### 9. SQLite 3 (`import sqlite3`)
- **Description**: Built-in ACID-compliant relational database engine.
- **Where Used**: `database/db_manager.py`.
- **Application Role & Overview**:
  - Manages local relational database file `smart_expense.db`.
  - Executes parameterized SQL statements to prevent SQL injection vulnerabilities.
  - Enables `sqlite3.Row` factory for dictionary-style database row access.

### 10. Datetime & Timedelta (`from datetime import datetime, timedelta`)
- **Description**: Standard library for date parsing, arithmetic, and formatting.
- **Where Used**: `analytics/calculations.py`, `modules/expense_manager.py`, `modules/income_manager.py`, `modules/budget_manager.py`.
- **Application Role & Overview**:
  - Computes dynamic date bounds ('Today', 'This Week', 'This Month', 'Last Month', 'Last 90 Days').
  - Parses date strings (`%Y-%m-%d`, `%Y-%m`) for SQL queries and grouping.

### 11. Unittest (`import unittest`)
- **Description**: Standard Python unit testing framework.
- **Where Used**: `tests/test_app.py`.
- **Application Role & Overview**:
  - Executes 7 unit tests verifying DB setup, input validation, CRUD workflows, budget tracking, data cleaning, statistics, and ML models.

---

## 3. Third-Party Python Libraries & Used Functions Matrix

| Library | Version / Requirement | Purpose & Application Role | Specific Functions & Classes Used |
| :--- | :--- | :--- | :--- |
| **`streamlit`** | `^1.30.0` | Web UI Framework & Dashboard Engine | `st.set_page_config()`, `st.markdown()`, `st.sidebar()`, `st.radio()`, `st.columns()`, `st.metric()`, `st.dataframe()`, `st.selectbox()`, `st.text_input()`, `st.number_input()`, `st.date_input()`, `st.form()`, `st.button()`, `st.plotly_chart()`, `st.pyplot()`, `st.download_button()`, `st.file_uploader()`, `st.progress()`, `st.rerun()` |
| **`pandas`** | `^2.1.0` | Data Processing & Manipulation | `pd.DataFrame()`, `pd.read_sql_query()`, `pd.read_csv()`, `pd.to_csv()`, `pd.to_datetime()`, `pd.to_numeric()`, `df.isnull()`, `df.duplicated()`, `df.drop_duplicates()`, `df.dropna()`, `df.fillna()`, `df.groupby()`, `df.agg()`, `pd.merge()`, `df.pivot_table()`, `series.cumsum()`, `series.quantile()`, `series.skew()`, `series.kurtosis()`, `series.mode()` |
| **`numpy`** | `^1.26.0` | Vectorized Numerical Computing | `np.where()`, `np.linspace()`, `np.isnan()`, `np.mean()`, `np.std()`, `np.array()` |
| **`plotly.express`** | `^5.18.0` | Interactive Visualizations | `px.pie()`, `px.histogram()`, `px.box()`, `px.imshow()`, `px.colors.qualitative.Pastel` |
| **`plotly.graph_objects`** | `^5.18.0` | Custom Low-Level Traces | `go.Figure()`, `go.Scatter()`, `go.Bar()`, `fig.update_layout()`, `fig.update_traces()`, `fig.add_trace()`, `fig.add_annotation()` |
| **`scipy.stats`** | `^1.11.0` | Statistical Computing & Inference | `stats.sem()`, `stats.t.ppf()`, `stats.ttest_1samp()`, `stats.norm.pdf()` |
| **`seaborn`** | `^0.13.0` | Statistical Data Visualization | `sns.set_theme()`, `sns.histplot()`, `sns.barplot()` |
| **`matplotlib.pyplot`** | `^3.8.0` | Plot Rendering Canvas Handles | `plt.subplots()`, `plt.tight_layout()`, `ax.text()`, `ax.plot()`, `ax.legend()` |
| **`scikit-learn`** | `^1.3.0` | ML Anomaly Detection Classifier | `IsolationForest(contamination, random_state).fit_predict()`, `decision_function()` |
| **`sqlite3`** | Standard Library | Local Relational Database Engine | `sqlite3.connect()`, `sqlite3.Row`, `conn.cursor()`, `cursor.execute()`, `cursor.executescript()`, `cursor.fetchall()`, `cursor.fetchone()`, `conn.commit()` |

---

## 4. System Architecture & Working Data Flow

```mermaid
flowchart TD
    A[User Action / CSV Import] --> B[Streamlit UI Layer - pages_custom/]
    B --> C[Input Validation & Sanitization - modules/]
    C --> D[SQLite Parameterized Storage - database/db_manager.py]
    D --> E[Data Extraction - Pandas DataFrame]
    E --> F[Data Cleaning Pipeline - modules/data_cleaning.py]
    E --> G[Analytics Engine - analytics/calculations.py]
    E --> H[Statistical & ML Engine - modules/anomaly_detection.py]
    G --> I[Visualization Builders - analytics/visualizations.py]
    H --> I
    I --> J[Rendered Dashboard & Charts - Streamlit UI]
```

---

## 5. Complete Data Visualizations & Graphs Catalog

| # | Graph Name | Library & Class | Chart Type | Data Plotted | How It Works & Key Insights |
| :-: | :--- | :--- | :--- | :--- | :--- |
| **1** | **Expense Distribution by Category** | `plotly.express.pie` | Donut Chart (`hole=0.4`) | Spending amount grouped by category | Aggregates expenses by category and computes percentage share per category with hover tooltips displaying exact amounts in ₹. |
| **2** | **Daily Expense Trend & Cumulative Growth** | `plotly.graph_objects.Scatter` | Multi-Trace Line Chart | Daily total spending & cumulative sum over time | Plots daily spending line with cyan markers (`#00D2FF`) overlaid with a dashed line tracking total accumulated spend (`cumsum`). |
| **3** | **Monthly Cash Flow: Income vs Expense** | `plotly.graph_objects.Bar` | Grouped Bar Chart | Monthly total income vs monthly total expenses | Groups transactions by month (`%Y-%m`), compares total incoming revenue (green `#00E676`) side-by-side with total outgoing expenses (red `#FF5252`). |
| **4** | **Expense Amount Distribution** | `plotly.express.histogram` | Histogram (25 Bins) | Frequency distribution of transaction amounts | Bins transaction values to show price ranges where expenses cluster (e.g. low-value daily purchases vs high-value items). |
| **5** | **Category-wise Statistical Outlier Spread** | `plotly.express.box` | Box & Whisker Plot | Outlier distribution per category | Displays median, upper quartile (Q3), lower quartile (Q1), interquartile range (IQR), and explicitly plots outlier data points beyond 1.5×IQR. |
| **6** | **Spending Density Heatmap** | `plotly.express.imshow` | 2D Density Heatmap | Day of Week (Mon–Sun) vs Category spend matrix | Constructs a pivot table of categories against days of the week, coloring matrix cells by total spend intensity using a `Purples` color scale. |
| **7** | **Empirical Distribution vs Normal Fit** | `seaborn.histplot` + `scipy.stats` | Density Histogram + Fitted Normal PDF Curve | Empirical transaction amounts vs theoretical Gaussian curve | Calculates sample mean ($\mu$) and standard deviation ($\sigma$), plots empirical KDE curve alongside SciPy's fitted normal curve (`stats.norm.pdf`). |
| **8** | **Total Spending by Category** | `seaborn.barplot` | Horizontal Bar Chart | Rank-ordered category total spending | Sorts spending categories in descending order and renders a horizontal bar chart with the `viridis` color palette. |

---

## 6. Database Schema & Persistence Layer

The database is built on **SQLite 3** (`database/smart_expense.db`) and initialized via `database/schema.sql`:

```sql
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category_type TEXT NOT NULL DEFAULT 'Expense'
);

CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    category TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    description TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS income (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    amount REAL NOT NULL CHECK(amount > 0),
    source TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    monthly_limit REAL NOT NULL CHECK(monthly_limit >= 0),
    month INTEGER NOT NULL,
    year INTEGER NOT NULL,
    UNIQUE(category, month, year)
);
```

---

## 7. Module-by-Module Code Breakdown

- **`app.py`**: Streamlit main entry point, custom CSS injection, auto-seeding engine, and sidebar radio router.
- **`database/db_manager.py`**: Thread-safe `DatabaseManager` providing SQLite connection factory, parameterized queries, and DataFrame fetching.
- **`modules/expense_manager.py` & `income_manager.py`**: Full CRUD logic, validation, and multi-criteria filters.
- **`modules/budget_manager.py`**: Monthly category budget setting and utilization alerts (On Track, Warning, Exceeded).
- **`modules/data_cleaning.py`**: 6-stage automated preprocessing pipeline (trimming, title-case normalization, date parsing, invalid amount dropping, imputation, duplicate dropping).
- **`modules/anomaly_detection.py`**: IQR, Z-Score, and Isolation Forest ML algorithms.
- **`modules/statistics_analysis.py`**: Descriptive stats, confidence intervals, t-tests, and normal PDF curve fitting.
- **`analytics/calculations.py` & `visualizations.py`**: Executive KPI metric engine and Plotly/Seaborn figure generators.
- **`tests/test_app.py`**: Pytest / Unittest suite (**7/7 tests passing - 100% pass rate**).

---

## 8. Statistical & Machine Learning Algorithms

- **Interquartile Range (IQR) Outlier Rule**: $\text{IQR} = Q_3 - Q_1, \quad \text{Upper Limit} = Q_3 + 1.5 \times \text{IQR}$.
- **Z-Score Thresholding**: $Z = (X - \mu) / \sigma$, flags transactions where $|Z| > 2.0$.
- **Scikit-Learn Isolation Forest Classifier**: Unsupervised decision tree ensemble isolating outliers based on path length.
- **One-Sample Student's t-Test**: Hypothesis test ($H_0: \mu = \mu_0$) using `scipy.stats.ttest_1samp`.

---

## 9. System Verification & Pass Rate

- **Command**: `python -m unittest tests/test_app.py`
- **Result**: `7/7 Tests Passed` (100% Pass Rate in 1.657 seconds).
