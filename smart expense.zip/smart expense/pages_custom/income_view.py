"""
Income Management View for Smart Expense System.
Handles adding, editing, deleting, and reviewing income streams.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from modules.income_manager import (
    add_income,
    update_income,
    delete_income,
    get_income_df,
    get_income_by_id,
    INCOME_SOURCES
)

def render_income_page():
    st.markdown("## 💰 Income Management")

    tab1, tab2, tab3 = st.tabs(["➕ Record Income", "📋 Income Transactions", "✏️ Edit / Delete Income"])

    # TAB 1: ADD INCOME
    with tab1:
        st.markdown("### Record Income Entry")
        with st.form("add_income_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                inc_date = st.date_input("Date Received", value=datetime.now().date())
                inc_amt = st.number_input("Amount (₹)", min_value=1.0, step=500.0, format="%.2f")
            with col2:
                inc_source = st.selectbox("Income Source", INCOME_SOURCES, index=0)
                inc_desc = st.text_input("Description", placeholder="e.g. Monthly stipend, Freelance payment")

            submit_inc = st.form_submit_button("💾 Save Income Record", use_container_width=True)
            if submit_inc:
                ok, msg = add_income(inc_date.strftime("%Y-%m-%d"), inc_amt, inc_source, inc_desc)
                if ok:
                    st.success(msg)
                    st.rerun()
                else:
                    st.error(msg)

    # TAB 2: MANAGE INCOME
    with tab2:
        st.markdown("### Income History")
        sel_sources = st.multiselect("Filter Income Sources", INCOME_SOURCES)
        inc_df = get_income_df(sources=sel_sources if sel_sources else None)

        st.markdown(f"**Total Income Records:** {len(inc_df)} | **Total Income Earned:** ₹{inc_df['amount'].sum():,.2f}" if not inc_df.empty else "**Total Income Records:** 0")

        if not inc_df.empty:
            st.dataframe(inc_df[["id", "date", "amount", "source", "description"]], use_container_width=True, hide_index=True)
        else:
            st.info("No income records found.")

    # TAB 3: EDIT / DELETE INCOME
    with tab3:
        st.markdown("### Edit or Remove Income Record")
        inc_id_input = st.number_input("Enter Income ID to Edit/Delete", min_value=1, step=1)
        target_inc = get_income_by_id(int(inc_id_input))

        if target_inc:
            st.success(f"Selected Income #{target_inc['id']}: ₹{target_inc['amount']:,.2f} on {target_inc['date']} ({target_inc['source']})")
            
            with st.form("edit_income_form"):
                col_e1, col_e2 = st.columns(2)
                with col_e1:
                    e_date = st.date_input("Date", value=datetime.strptime(target_inc['date'], "%Y-%m-%d").date())
                    e_amt = st.number_input("Amount (₹)", value=float(target_inc['amount']), min_value=1.0, step=100.0)
                with col_e2:
                    e_src_idx = INCOME_SOURCES.index(target_inc['source']) if target_inc['source'] in INCOME_SOURCES else 0
                    e_src = st.selectbox("Source", INCOME_SOURCES, index=e_src_idx)
                    e_desc = st.text_input("Description", value=target_inc['description'] or "")

                col_b1, col_b2 = st.columns(2)
                with col_b1:
                    save_edit = st.form_submit_button("✏️ Update Income", use_container_width=True)
                with col_b2:
                    delete_rec = st.form_submit_button("🗑️ Delete Income", type="primary", use_container_width=True)

                if save_edit:
                    ok, msg = update_income(target_inc['id'], e_date.strftime("%Y-%m-%d"), e_amt, e_src, e_desc)
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)

                if delete_rec:
                    ok, msg = delete_income(target_inc['id'])
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)
        else:
            st.warning("No income record found with the specified ID.")
