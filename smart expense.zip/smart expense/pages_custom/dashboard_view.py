"""
Dashboard View for Smart Expense & Financial Analytics System.
Displays top KPI metrics cards, date filter selector, and primary interactive analytics charts.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from analytics.calculations import get_date_range_bounds, calculate_dashboard_kpis
from modules.expense_manager import get_expenses_df
from modules.income_manager import get_income_df
from analytics.visualizations import (
    create_category_pie_chart,
    create_daily_trend_line_chart,
    create_income_vs_expense_bar_chart,
    create_amount_histogram
)

def render_dashboard_page():
    st.markdown("## 📊 Financial Analytics Dashboard")
    st.markdown("##### Real-time Personal Expense & Cash Flow Analytics")

    # Date Filter Controls
    col_filter1, col_filter2, col_filter3 = st.columns([2, 2, 3])
    with col_filter1:
        date_preset = st.selectbox(
            "📅 Date Range Filter",
            ["This Month", "Today", "This Week", "Last Month", "Last 90 Days", "All Time", "Custom"],
            index=4
        )

    custom_start, custom_end = None, None
    if date_preset == "Custom":
        with col_filter2:
            custom_start = st.date_input("Start Date", value=datetime.now().date()).strftime("%Y-%m-%d")
        with col_filter3:
            custom_end = st.date_input("End Date", value=datetime.now().date()).strftime("%Y-%m-%d")

    start_date, end_date = get_date_range_bounds(date_preset, custom_start, custom_end)

    # Calculate KPIs
    kpis = calculate_dashboard_kpis(start_date, end_date)

    # KPI Metric Cards Row 1
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.metric("Total Income", f"₹{kpis['total_income']:,.2f}")
    with m2:
        st.metric("Total Expenses", f"₹{kpis['total_expenses']:,.2f}")
    with m3:
        balance_color = "normal" if kpis['current_balance'] >= 0 else "inverse"
        st.metric("Current Balance", f"₹{kpis['current_balance']:,.2f}", delta=f"{kpis['current_balance']:,.2f}")
    with m4:
        st.metric("Monthly Expenses", f"₹{kpis['monthly_expense']:,.2f}")

    # KPI Metric Cards Row 2
    m5, m6, m7, m8 = st.columns(4)
    with m5:
        st.metric("Daily Avg Expense", f"₹{kpis['daily_avg']:,.2f}")
    with m6:
        st.metric("Highest Category", kpis['highest_category'], help=f"Total spent: ₹{kpis['highest_category_amount']:,.2f}")
    with m7:
        st.metric("Total Transactions", str(kpis['transaction_count']))
    with m8:
        savings_ratio = (kpis['current_balance'] / kpis['total_income'] * 100) if kpis['total_income'] > 0 else 0.0
        st.metric("Net Savings Rate", f"{savings_ratio:.1f}%")

    st.markdown("---")

    # Fetch data for charts
    exp_df = get_expenses_df(start_date=start_date, end_date=end_date)
    inc_df = get_income_df(start_date=start_date, end_date=end_date)

    # Interactive Charts Grid
    chart_col1, chart_col2 = st.columns(2)
    with chart_col1:
        st.plotly_chart(create_category_pie_chart(exp_df), use_container_width=True)
    with chart_col2:
        st.plotly_chart(create_income_vs_expense_bar_chart(exp_df, inc_df), use_container_width=True)

    chart_col3, chart_col4 = st.columns(2)
    with chart_col3:
        st.plotly_chart(create_daily_trend_line_chart(exp_df), use_container_width=True)
    with chart_col4:
        st.plotly_chart(create_amount_histogram(exp_df), use_container_width=True)

    # Recent Transactions Preview
    st.markdown("### 🕒 Recent Expense Transactions")
    if not exp_df.empty:
        st.dataframe(
            exp_df[["id", "date", "amount", "category", "payment_method", "description", "notes"]].head(8),
            use_container_width=True,
            hide_index=True
        )
    else:
        st.info("No expense transactions recorded for the selected date range.")
