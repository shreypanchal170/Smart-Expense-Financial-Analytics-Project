"""
Import / Export & Backup View for Smart Expense System.
Handles importing CSV files, schema validation, duplicate prevention, and exporting datasets.
"""

import streamlit as st
import pandas as pd
from modules.expense_manager import get_expenses_df
from modules.income_manager import get_income_df
from modules.reports import import_expenses_from_csv, import_income_from_csv, export_to_csv

def render_import_export_page():
    st.markdown("## 📁 Data Import, Export & Backup")
    st.markdown("##### File Handling (CSV & Data I/O)")

    tab1, tab2, tab3 = st.tabs(["📥 Import Data from CSV", "📤 Export Reports to CSV", "📄 Download Sample CSV Templates"])

    # TAB 1: CSV IMPORT
    with tab1:
        st.markdown("### Import Expenses from CSV")
        st.caption("Required columns: `date`, `amount`, `category`, `payment_method` (Optional: `description`, `notes`)")

        uploaded_exp = st.file_uploader("Upload Expense CSV File", type=["csv"], key="exp_csv_uploader")
        if uploaded_exp is not None:
            if st.button("🚀 Process & Import Expense CSV", use_container_width=True):
                ok, msg, summary = import_expenses_from_csv(uploaded_exp)
                if ok:
                    st.success(msg)
                    i1, i2, i3 = st.columns(3)
                    with i1:
                        st.metric("Total Rows", str(summary.get("total_rows", 0)))
                    with i2:
                        st.metric("Successfully Imported", str(summary.get("imported_count", 0)))
                    with i3:
                        st.metric("Skipped / Duplicates", str(summary.get("skipped_count", 0)))

                    if summary.get("errors"):
                        with st.expander("View Import Warnings & Errors"):
                            for err in summary["errors"]:
                                st.write(f"- {err}")
                    st.rerun()
                else:
                    st.error(msg)

        st.markdown("---")
        st.markdown("### Import Income from CSV")
        st.caption("Required columns: `date`, `amount`, `source` (Optional: `description`)")

        uploaded_inc = st.file_uploader("Upload Income CSV File", type=["csv"], key="inc_csv_uploader")
        if uploaded_inc is not None:
            if st.button("🚀 Process & Import Income CSV", use_container_width=True):
                ok, msg, summary = import_income_from_csv(uploaded_inc)
                if ok:
                    st.success(msg)
                    st.rerun()
                else:
                    st.error(msg)

    # TAB 2: CSV EXPORT
    with tab2:
        st.markdown("### Export Financial Records to CSV")
        exp_df = get_expenses_df()
        inc_df = get_income_df()

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("#### Expense Records")
            st.write(f"Total Expenses: {len(exp_df)} records")
            if not exp_df.empty:
                exp_csv_str = export_to_csv(exp_df)
                st.download_button(
                    label="💾 Download Expenses CSV",
                    data=exp_csv_str,
                    file_name="expenses_export.csv",
                    mime="text/csv",
                    use_container_width=True
                )
        with c2:
            st.markdown("#### Income Records")
            st.write(f"Total Income: {len(inc_df)} records")
            if not inc_df.empty:
                inc_csv_str = export_to_csv(inc_df)
                st.download_button(
                    label="💾 Download Income CSV",
                    data=inc_csv_str,
                    file_name="income_export.csv",
                    mime="text/csv",
                    use_container_width=True
                )

    # TAB 3: SAMPLE TEMPLATES
    with tab3:
        st.markdown("### Sample CSV Templates for Data Loading")
        st.write("Download pre-formatted sample files to test import capabilities:")

        sample_exp_data = "date,amount,category,payment_method,description,notes\n2026-09-01,450.00,Food,UPI,Canteen Lunch,Student budget\n2026-09-02,1200.00,Education,Net Banking,Reference Textbook,Educational Resources"
        sample_inc_data = "date,amount,source,description\n2026-09-01,15000.00,Allowance,Parental Support\n2026-09-05,5000.00,Freelance,Python Web Scraping Project"

        t1, t2 = st.columns(2)
        with t1:
            st.download_button(
                "📄 Download Sample Expense CSV",
                data=sample_exp_data,
                file_name="sample_expenses_template.csv",
                mime="text/csv",
                use_container_width=True
            )
        with t2:
            st.download_button(
                "📄 Download Sample Income CSV",
                data=sample_inc_data,
                file_name="sample_income_template.csv",
                mime="text/csv",
                use_container_width=True
            )
