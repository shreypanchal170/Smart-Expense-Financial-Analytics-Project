"""
Expenses View for Smart Expense System.
Allows recording new expenses, updating, deleting, searching, filtering, and sorting transactions.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from modules.expense_manager import (
    add_expense,
    update_expense,
    delete_expense,
    get_expenses_df,
    get_expense_by_id,
    PAYMENT_METHODS
)
from modules.category_manager import get_all_categories

def render_expenses_page():
    st.markdown("## 📑 Expense Management")

    categories = get_all_categories("Expense")

    tab1, tab2, tab3 = st.tabs(["➕ Record New Expense", "🔍 Manage & Search Expenses", "✏️ Edit / Delete Expense"])

    # --- TAB 1: ADD EXPENSE ---
    with tab1:
        st.markdown("### Record a New Expense Transaction")
        with st.form("add_expense_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                exp_date = st.date_input("Transaction Date", value=datetime.now().date())
                exp_amount = st.number_input("Amount (₹)", min_value=0.01, step=10.0, format="%.2f")
                exp_cat = st.selectbox("Category", categories, index=0)
            with col2:
                exp_pm = st.selectbox("Payment Method", PAYMENT_METHODS, index=0)
                exp_desc = st.text_input("Description / Item Name", placeholder="e.g. Mess Fee, Books, Petrol")
                exp_notes = st.text_area("Optional Notes", placeholder="e.g. Shared with roommate", height=68)

            submit_btn = st.form_submit_button("💾 Save Expense Record", use_container_width=True)

            if submit_btn:
                date_str = exp_date.strftime("%Y-%m-%d")
                success, msg = add_expense(date_str, exp_amount, exp_cat, exp_pm, exp_desc, exp_notes)
                if success:
                    st.success(msg)
                    st.rerun()
                else:
                    st.error(msg)

    # --- TAB 2: MANAGE & SEARCH EXPENSES ---
    with tab2:
        st.markdown("### Search & Filter Expenses")

        filter_col1, filter_col2, filter_col3 = st.columns(3)
        with filter_col1:
            search_q = st.text_input("🔎 Search Description / Notes", placeholder="Type keyword...")
        with filter_col2:
            sel_cats = st.multiselect("Filter Categories", categories)
        with filter_col3:
            sel_pms = st.multiselect("Filter Payment Methods", PAYMENT_METHODS)

        sort_col1, sort_col2 = st.columns(2)
        with sort_col1:
            sort_by = st.selectbox("Sort By", ["date", "amount", "category", "id"], index=0)
        with sort_col2:
            order_asc = st.radio("Order", ["Descending (Newest / Highest First)", "Ascending"], index=0) == "Ascending"

        df = get_expenses_df(
            categories=sel_cats if sel_cats else None,
            payment_methods=sel_pms if sel_pms else None,
            search_query=search_q,
            sort_by=sort_by,
            ascending=order_asc
        )

        st.markdown(f"**Total Records Found:** {len(df)} | **Total Amount:** ₹{df['amount'].sum():,.2f}" if not df.empty else "**Total Records Found:** 0")

        if not df.empty:
            st.dataframe(df[["id", "date", "amount", "category", "payment_method", "description", "notes"]], use_container_width=True, hide_index=True)
        else:
            st.info("No matching expense transactions found.")

    # --- TAB 3: EDIT / DELETE EXPENSE ---
    with tab3:
        st.markdown("### Edit or Remove an Existing Expense")
        exp_id_input = st.number_input("Enter Expense ID to Edit/Delete", min_value=1, step=1)
        target_exp = get_expense_by_id(int(exp_id_input))

        if target_exp:
            st.success(f"Selected Expense #{target_exp['id']}: ₹{target_exp['amount']:,.2f} on {target_exp['date']} ({target_exp['category']})")
            
            with st.form("edit_expense_form"):
                col_e1, col_e2 = st.columns(2)
                with col_e1:
                    e_date = st.date_input("Date", value=datetime.strptime(target_exp['date'], "%Y-%m-%d").date())
                    e_amt = st.number_input("Amount (₹)", value=float(target_exp['amount']), min_value=0.01, step=10.0)
                    e_cat_idx = categories.index(target_exp['category']) if target_exp['category'] in categories else 0
                    e_cat = st.selectbox("Category", categories, index=e_cat_idx)
                with col_e2:
                    e_pm_idx = PAYMENT_METHODS.index(target_exp['payment_method']) if target_exp['payment_method'] in PAYMENT_METHODS else 0
                    e_pm = st.selectbox("Payment Method", PAYMENT_METHODS, index=e_pm_idx)
                    e_desc = st.text_input("Description", value=target_exp['description'] or "")
                    e_notes = st.text_area("Notes", value=target_exp['notes'] or "")

                col_btn1, col_btn2 = st.columns(2)
                with col_btn1:
                    save_edit = st.form_submit_button("✏️ Update Record", use_container_width=True)
                with col_btn2:
                    delete_rec = st.form_submit_button("🗑️ Delete Record", type="primary", use_container_width=True)

                if save_edit:
                    ok, msg = update_expense(target_exp['id'], e_date.strftime("%Y-%m-%d"), e_amt, e_cat, e_pm, e_desc, e_notes)
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)

                if delete_rec:
                    ok, msg = delete_expense(target_exp['id'])
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)
        else:
            st.warning("No expense found with the specified ID.")
