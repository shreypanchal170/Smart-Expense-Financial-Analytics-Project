"""
Data Preprocessing & Cleaning View for Smart Expense System.
Implements data cleaning pipeline and interactive audit reports.
"""

import streamlit as st
import pandas as pd
from modules.expense_manager import get_expenses_df
from modules.data_cleaning import DataCleaner

def render_cleaning_page():
    st.markdown("## 🧹 Data Preprocessing & Cleaning Pipeline")
    st.markdown("##### Automated Data Quality Audit, Missing Value Imputation, Deduplication & Text Normalization")

    raw_df = get_expenses_df()
    if raw_df.empty:
        st.warning("No expense data available for cleaning. Add records or seed sample data.")
        return

    cleaner = DataCleaner(raw_df)
    quality = cleaner.inspect_data_quality()

    st.markdown("### 1. Data Quality Inspection Report")
    q1, q2, q3, q4 = st.columns(4)
    with q1:
        st.metric("Total Records", str(quality["total_rows"]))
    with q2:
        st.metric("Missing Values", str(quality["total_missing_cells"]))
    with q3:
        st.metric("Duplicate Records", str(quality["duplicates"]))
    with q4:
        st.metric("Invalid Amounts (<= 0)", str(quality["invalid_amounts"]))

    st.markdown("---")

    # Cleaning Controls
    st.markdown("### 2. Configure Cleaning Pipeline")
    c_col1, c_col2, c_col3 = st.columns(3)
    with c_col1:
        opt_dups = st.checkbox("Remove Duplicate Transactions", value=True)
    with c_col2:
        opt_missing = st.checkbox("Impute Missing Text Fields", value=True)
    with c_col3:
        opt_norm = st.checkbox("Normalize Categories to Title Case", value=True)

    if st.button("🚀 Execute Data Cleaning Pipeline", use_container_width=True):
        cleaned_df, summary = cleaner.clean_pipeline(
            drop_duplicates=opt_dups,
            fill_missing=opt_missing,
            normalize_categories=opt_norm
        )

        st.success(f"Pipeline executed! Removed {summary['removed_rows']} problematic row(s). Final clean count: {summary['final_rows']} rows.")

        st.markdown("#### Pipeline Operation Audit Log:")
        for log_entry in summary["pipeline_logs"]:
            st.markdown(f"- ✅ {log_entry}")

        st.markdown("#### Cleaned Dataset Preview:")
        st.dataframe(cleaned_df.head(10), use_container_width=True, hide_index=True)
