"""
Financial Analytics & Visualizations View for Smart Expense System.
Renders Plotly interactive charts and Seaborn statistical visualization figures.
"""

import streamlit as st
from modules.expense_manager import get_expenses_df
from modules.income_manager import get_income_df
from analytics.visualizations import (
    create_category_pie_chart,
    create_daily_trend_line_chart,
    create_income_vs_expense_bar_chart,
    create_amount_histogram,
    create_box_plot_outliers,
    create_spending_heatmap,
    generate_seaborn_statistical_plots
)

def render_analytics_page():
    st.markdown("## 📈 Financial Analytics & Visualizations")
    st.markdown("##### Detailed graphical breakdown of spending habits, distribution, and trends.")

    exp_df = get_expenses_df()
    inc_df = get_income_df()

    if exp_df.empty:
        st.warning("No expense data available. Please add transactions or load sample data from Settings.")
        return

    # Tabs for chart categories
    tab1, tab2, tab3, tab4 = st.tabs([
        "🥧 Category & Distribution",
        "📉 Daily & Cash Flow Trends",
        "📦 Box Plots & Heatmap",
        "📊 Statistical Seaborn Plots"
    ])

    with tab1:
        st.markdown("### Category Spending & Amount Distribution")
        c1, c2 = st.columns(2)
        with c1:
            st.plotly_chart(create_category_pie_chart(exp_df), use_container_width=True)
        with c2:
            st.plotly_chart(create_amount_histogram(exp_df), use_container_width=True)

    with tab2:
        st.markdown("### Daily Spending Growth & Cash Flow")
        c3, c4 = st.columns(2)
        with c3:
            st.plotly_chart(create_daily_trend_line_chart(exp_df), use_container_width=True)
        with c4:
            st.plotly_chart(create_income_vs_expense_bar_chart(exp_df, inc_df), use_container_width=True)

    with tab3:
        st.markdown("### Statistical Outlier Box Plot & Spending Heatmap")
        st.plotly_chart(create_box_plot_outliers(exp_df), use_container_width=True)
        st.plotly_chart(create_spending_heatmap(exp_df), use_container_width=True)

    with tab4:
        st.markdown("### Matplotlib & Seaborn Visualizations")
        st.info("Demonstrating static statistical plotting using Matplotlib & Seaborn.")
        fig_dist, fig_bar = generate_seaborn_statistical_plots(exp_df)
        
        sb_col1, sb_col2 = st.columns(2)
        with sb_col1:
            st.pyplot(fig_dist)
        with sb_col2:
            st.pyplot(fig_bar)
