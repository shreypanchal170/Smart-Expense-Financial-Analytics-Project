"""
Budget Management View for Smart Expense System.
Allows users to define category limits, inspect budget utilization progress bars, and view overspend alerts.
"""

import streamlit as st
from datetime import datetime
from modules.budget_manager import set_budget, get_budget_status, delete_budget
from modules.category_manager import get_all_categories

def render_budgets_page():
    st.markdown("## 🎯 Budget Management")

    categories = get_all_categories("Expense")
    now = datetime.now()

    col_m, col_y = st.columns(2)
    with col_m:
        sel_month = st.selectbox("Select Month", list(range(1, 13)), index=now.month - 1, format_func=lambda x: datetime(2026, x, 1).strftime("%B"))
    with col_y:
        sel_year = st.selectbox("Select Year", [now.year - 1, now.year, now.year + 1], index=1)

    st.markdown("---")

    # Set New / Update Budget Form
    st.markdown("### Set Category Budget Limit")
    with st.form("set_budget_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        with c1:
            budget_cat = st.selectbox("Category", categories)
        with c2:
            budget_limit = st.number_input("Monthly Limit (₹)", min_value=100.0, step=500.0, value=5000.0)

        submit_budget = st.form_submit_button("💾 Set Budget Limit", use_container_width=True)
        if submit_budget:
            ok, msg = set_budget(budget_cat, budget_limit, sel_month, sel_year)
            if ok:
                st.success(msg)
                st.rerun()
            else:
                st.error(msg)

    st.markdown("---")
    st.markdown(f"### 📈 Budget Utilization - {datetime(sel_year, sel_month, 1).strftime('%B %Y')}")

    statuses = get_budget_status(sel_month, sel_year)

    if statuses:
        for item in statuses:
            col_info, col_prog = st.columns([2, 3])
            with col_info:
                badge_emoji = "✅" if item["status"] == "On Track" else ("⚠️" if item["status"] == "Warning" else "🚨")
                st.markdown(f"#### {badge_emoji} {item['category']}")
                st.write(f"**Limit:** ₹{item['monthly_limit']:,.2f} | **Spent:** ₹{item['spent']:,.2f} | **Remaining:** ₹{item['remaining']:,.2f}")
                st.caption(f"Status: {item['status']} ({item['utilization_pct']}%)")
            with col_prog:
                # Progress bar calculation (clamped between 0 and 1.0)
                prog_val = min(float(item["utilization_pct"]) / 100.0, 1.0)
                st.progress(prog_val)
                if st.button(f"Delete Budget #{item['id']}", key=f"del_b_{item['id']}"):
                    delete_budget(item["id"])
                    st.success(f"Budget for {item['category']} removed.")
                    st.rerun()
            st.markdown("---")
    else:
        st.info(f"No budgets configured for {datetime(sel_year, sel_month, 1).strftime('%B %Y')}. Use the form above to add a category limit.")
