"""
Settings & Database Administration View for Smart Expense System.
Provides sample data seeding, database reset tools, and custom category configuration.
"""

import os
import streamlit as st
import pandas as pd
from database.db_manager import db
from data.generate_sample_data import generate_sample_datasets
from modules.reports import import_expenses_from_csv, import_income_from_csv
from modules.category_manager import get_all_categories, add_category, delete_category

def render_settings_page():
    st.markdown("## ⚙️ Settings & System Administration")

    tab1, tab2 = st.tabs(["🌱 Seed Demonstration Data", "🏷️ Custom Categories"])

    # TAB 1: SEED SAMPLE DATA
    with tab1:
        st.markdown("### Seed Demonstration Data")
        st.write("""
        Quickly populate the SQLite database with **65 realistic expenses** and **22 income records** 
        spanning 90 days. This includes varied categories, payment methods, and statistical outliers 
        specifically formatted to demonstrate analytics and anomaly detection algorithms (IQR, Z-Score, Isolation Forest, Normal Fit).
        """)

        s_col1, s_col2 = st.columns(2)
        with s_col1:
            if st.button("🌱 Load Sample Dataset", type="primary", use_container_width=True):
                # Ensure CSV files exist
                data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
                exp_csv = os.path.join(data_dir, "sample_expenses.csv")
                inc_csv = os.path.join(data_dir, "sample_income.csv")

                if not os.path.exists(exp_csv) or not os.path.exists(inc_csv):
                    generate_sample_datasets()

                with open(exp_csv, "rb") as f_exp:
                    import_expenses_from_csv(f_exp)
                with open(inc_csv, "rb") as f_inc:
                    import_income_from_csv(f_inc)

                st.success("Sample dataset successfully loaded into SQLite database!")
                st.rerun()

        with s_col2:
            if st.button("🚨 Wipe All Database Records", use_container_width=True):
                db.clear_database()
                st.warning("All expense, income, and budget data wiped!")
                st.rerun()

    # TAB 2: CUSTOM CATEGORIES
    with tab2:
        st.markdown("### Manage Custom Expense Categories")
        existing_cats = get_all_categories("Expense")

        st.markdown("#### Existing Expense Categories:")
        st.write(", ".join([f"`{c}`" for c in existing_cats]))

        c1, c2 = st.columns(2)
        with c1:
            with st.form("add_cat_form"):
                new_cat_name = st.text_input("New Category Name")
                if st.form_submit_button("➕ Add Category", use_container_width=True):
                    if new_cat_name:
                        add_category(new_cat_name, "Expense")
                        st.success(f"Category '{new_cat_name}' added!")
                        st.rerun()
        with c2:
            with st.form("del_cat_form"):
                del_cat_name = st.selectbox("Select Category to Remove", existing_cats)
                if st.form_submit_button("🗑️ Delete Category", use_container_width=True):
                    delete_category(del_cat_name)
                    st.success(f"Category '{del_cat_name}' deleted!")
                    st.rerun()
