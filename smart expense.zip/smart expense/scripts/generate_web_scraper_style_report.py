import os
import sys

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

DOCS_DIR = r"c:\Users\Admin\smart expense\docs"
os.makedirs(DOCS_DIR, exist_ok=True)
PDF_PATH = os.path.join(DOCS_DIR, "Smart_Expense_Project_Structure_Report.pdf")

print("Generating PDF Document (.pdf)...")

doc_pdf = SimpleDocTemplate(
    PDF_PATH,
    pagesize=letter,
    leftMargin=45, rightMargin=45,
    topMargin=45, bottomMargin=45
)

styles = getSampleStyleSheet()
title_style = ParagraphStyle('TitleStyle', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=18, textColor=colors.HexColor("#0F172A"), leading=26, alignment=1)
h1_style = ParagraphStyle('H1Style', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=14, textColor=colors.HexColor("#0F172A"), leading=19, spaceBefore=14, spaceAfter=6)
h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=12, textColor=colors.HexColor("#0EA5E9"), leading=15, spaceBefore=10, spaceAfter=4)
body_style = ParagraphStyle('BodyStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=10, textColor=colors.HexColor("#334155"), leading=14, spaceAfter=6)
bullet_style = ParagraphStyle('BulletStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=10, textColor=colors.HexColor("#1E293B"), leading=14, spaceAfter=4)
code_style = ParagraphStyle('CodeStyle', parent=styles['Code'], fontName='Courier', fontSize=9, textColor=colors.HexColor("#b91c1c"), leading=12, spaceAfter=6)

elements = []

def add_h1(text): elements.append(Paragraph(text, h1_style))
def add_h2(text): elements.append(Paragraph(text, h2_style))
def add_p(text): elements.append(Paragraph(text, body_style))
def add_bullet(text): elements.append(Paragraph(f"• {text}", bullet_style))
def add_code(text): elements.append(Paragraph(text, code_style))

# Title
elements.append(Paragraph("Smart Expense & Financial Analytics Project Report", title_style))
elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0EA5E9"), spaceAfter=12))

# 1. Project Overview
add_h1("1. Project Overview")
add_p("The project is a comprehensive desktop and web-based Smart Expense & Financial Analytics System made using Python. The user interacts with the application to manage expenses and income, and the application stores data in a local database, runs statistical data cleaning pipelines, performs machine learning anomaly detection, displays interactive dashboards, and supports CSV export and import into the database. The application also inspects historical spending statistics and displays them using Plotly, Matplotlib, and Seaborn charts.")
add_p("<b>Main features:</b>")
add_bullet("Enter income and expense records.")
add_bullet("Inspect basic monthly and yearly statistics.")
add_bullet("Calculate and track category budgets.")
add_bullet("Perform 6-stage data cleaning operations.")
add_bullet("Detect anomalous transactions using machine learning.")
add_bullet("Display interactive Key Performance Indicators (KPIs).")
add_bullet("Display results in interactive tables.")
add_bullet("Export financial data to CSV.")
add_bullet("Create interactive Pie, Bar, Heatmap, and Line charts.")

# 2. Technologies Used
add_h1("2. Technologies Used")
t_data = [
    [Paragraph("<b>Technology</b>", bullet_style), Paragraph("<b>Purpose</b>", bullet_style), Paragraph("<b>Simple Meaning</b>", bullet_style)],
    [Paragraph("Python", bullet_style), Paragraph("Main programming language", bullet_style), Paragraph("Controls the whole application", bullet_style)],
    [Paragraph("Streamlit", bullet_style), Paragraph("GUI", bullet_style), Paragraph("Creates the graphical dashboard, sidebar, buttons, and inputs", bullet_style)],
    [Paragraph("SQLite3", bullet_style), Paragraph("Database", bullet_style), Paragraph("Stores the user's data locally and securely", bullet_style)],
    [Paragraph("Pandas", bullet_style), Paragraph("Data processing", bullet_style), Paragraph("Reads DB data, groups rows, and handles cleaning", bullet_style)],
    [Paragraph("Plotly/Matplotlib", bullet_style), Paragraph("Visualization", bullet_style), Paragraph("Creates Bar, Pie, Heatmap, and Line charts", bullet_style)],
    [Paragraph("Scikit-Learn", bullet_style), Paragraph("Anomaly Detection", bullet_style), Paragraph("Machine learning tool to find unusual expenses", bullet_style)]
]
pdf_table1 = Table(t_data, colWidths=[100, 150, 180])
pdf_table1.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#f1f5f9")),
    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
]))
elements.append(pdf_table1)
elements.append(Spacer(1, 10))

# 3. How the Project Works
add_h1("3. How the Project Works")
add_p("The complete flow is:")
add_p("User interacts with GUI Sidebar")
add_p("↓")
add_p("Streamlit GUI receives input (e.g., Expense amount)")
add_p("↓")
add_p("Data is validated by logic modules")
add_p("↓")
add_p("SQLite3 stores data securely in smart_expense.db")
add_p("↓")
add_p("Pandas retrieves and cleans data from the database")
add_p("↓")
add_p("Analytics Module calculates KPIs and trends")
add_p("↓")
add_p("Statistics are visualized with Plotly/Matplotlib")
add_p("↓")
add_p("Dashboard renders final metrics and interactive plots")

# 4. Project Libraries
add_h1("4. Project Libraries")
add_h2("4.1 Streamlit")
add_p("Streamlit is the Python library for creating a graphical user interface and dashboard. In this project it creates the web interface and visible controls.")
add_bullet("st.set_page_config() sets the page title and theme.")
add_bullet("st.sidebar creates the side navigation menu.")
add_bullet("st.radio() creates the page routing mechanism.")
add_bullet("st.number_input() and st.text_input() capture numerical and text data.")
add_bullet("st.dataframe() displays financial records in rows and columns.")
add_bullet("st.success() and st.error() show notification popups.")

add_h2("4.2 SQLite")
add_p("The sqlite3 module securely handles the local database storage. The connection is managed securely with parameterized queries across tables for expenses, income, budgets, and categories.")
add_code("conn = sqlite3.connect('smart_expense.db')")
add_code("cursor.execute('INSERT INTO expenses (date, amount) VALUES (?,?)', (d, a))")

add_h2("4.3 Pandas")
add_p("Pandas is used to read database tables directly into DataFrames, merge tables, filter, group, and query large arrays of transactions.")
add_code("df = pd.read_sql_query('SELECT * FROM expenses', conn)")
add_bullet("groupby('category')['amount'].sum() calculates totals.")
add_bullet("dropna() and drop_duplicates() clean data automatically.")

add_h2("4.4 Plotly & Seaborn")
add_p("These libraries create advanced interactive charts. Plotly displays the interactive charts within Streamlit.")
add_bullet("px.pie() creates interactive pie charts.")
add_bullet("px.histogram() creates amount distribution bars.")
add_bullet("sns.histplot() calculates distribution estimations.")

# 5. Main Design Architecture
add_h1("5. Main Application Design")
add_p("The application separates concerns by keeping GUI components partitioned inside pages_custom/ and database operations in database/db_manager.py, while analytical features are in analytics/ and modules/.")

# 6. Program Starting Point
add_h1("6. Program Starting Point")
add_p("To run the Streamlit app, we launch app.py using the Streamlit engine.")
add_code("streamlit run app.py")
add_p("Within the code, the routing logic directs users to the different pages:")
add_code('if page_choice == "📊 Dashboard": render_dashboard_page()')

# 7. Initialization Database Setup
add_h1("7. Database Initialization")
add_p("Upon startup, DB logic runs automatically generating tables and adding sample data if empty.")
add_code("def auto_seed_if_empty(): ...")

# 8. GUI Structure
add_h1("8. GUI Structure")
add_p("The application has eight main view paths routed from a unified sidebar:")
add_bullet("Dashboard: Overview charts and combined financial summaries.")
add_bullet("Manage Expenses: Form for logging daily expenses and viewing tables.")
add_bullet("Income Management: Form for logging income sources.")
add_bullet("Budget Management: Setting thresholds and comparing vs tracking limits.")
add_bullet("Financial Analytics: Interactive anomaly mapping and distribution.")
add_bullet("Data Cleaning Pipeline: Cleaning operations applied sequentially.")
add_bullet("Import / Export CSV: Saving or retrieving csv file backups.")
add_bullet("Settings & DB Admin: Drop tables and reset modes.")

# 9. Data Input Process
add_h1("9. Transaction Input")
add_p("The user enters dates, text, and numbers inside a form component.")
add_code("with st.form('add_record_form'):")
add_code("    amount = st.number_input('Amount', min_value=0.01)")
add_p("Input conditions enforce minimum amounts to prevent invalid entries.")

# 10. Database Saving Process
add_h1("10. Processing the Transaction")
add_p("When the user clicks the submit button, logic invokes manager files.")
add_p("Step 1: Get values stripping any whitespace. Validate inputs.")
add_p("Step 2: Database executes the specific insert query via parameterized injection protection.")
add_p("Step 3: St.rerun() triggers the GUI to refresh immediately showing new values.")

# 11. Extracting Categories
add_h1("11. Querying Categories & Distributions")
add_p("Group-by commands run over columns to summarize categorical totals:")
add_code("cat_df = df.groupby('category')['amount'].sum()")

# 12. Displaying Tables
add_h1("12. Displaying Results")
add_p("Financial records display directly using standard tables UI components:")
add_code("st.dataframe(filtered_df, use_container_width=True)")
add_p("If no records are found, an explicit 'No Records Found' message displays.")

# 13. Anomaly Detection Engine
add_h1("13. Scikit-Learn Anomaly Detection")
add_p("The AI component uses an IsolationForest to search for suspicious spending automatically:")
add_code("model = IsolationForest(contamination=0.05)")
add_code("df['anomaly'] = model.fit_predict(df[['amount']])")

# 14. Data Cleaning Procedures
add_h1("14. Automated Data Cleaning")
add_p("The application automatically imputes missing amounts and removes identical transaction duplicate entries ensuring clean reporting data.")

# 15. Validation Notifications
add_h1("15. Form Status Results")
add_p("Streamlit surfaces success messages upon completed transactions and displays UI warnings when errors occur.")
add_code("st.success('Transaction Saved Successfully!')")

# 16. Visualization Integrations
add_h1("16. Visualization Dashboards")
add_p("The Visualization tools provide deep analytics types including:")
add_bullet("Bar Chart (Income vs Expense grouping)")
add_bullet("Pie Chart (Expense Category Distribution)")
add_bullet("Line Chart (Daily Cumulative Spend Trend)")
add_bullet("Heatmaps (Day of Week vs Category density)")

# 17. Displaying Matplotlib/Plotly inside Streamlit
add_h1("17. Displaying Charts inside Tkinter/Streamlit")
add_p("The project uses native streamlit embedding modules to map Plotly HTML components to the screen:")
add_code("st.plotly_chart(fig, use_container_width=True)")
add_p("For Matplotlib:")
add_code("st.pyplot(fig)")

# 18. CSV Exporting
add_h1("18. CSV Export and Import")
add_p("Users interact with file up-loaders and download buttons to manage csv backups securely utilizing Pandas converting capabilities.")
add_code("csv_data = df.to_csv(index=False).encode('utf-8')")
add_code("st.download_button(label='Export CSV', data=csv_data)")

# 19. Administrative Clear Button
add_h1("19. Administrative Reset")
add_p("A clear button is available in the admin section to drop all SQL tables allowing a fresh database restart by initializing reset sequences.")

# 20. Error Handling
add_h1("20. Application Error Handling")
add_p("Try/Except blocks prevent application failures through controlled rollbacks if bad transactions are attempted:")
add_code("try:\n    execute_insert_query()\nexcept Exception as error:\n    return False, str(error)")

# 21. Python Concepts
add_h1("21. Important Python Concepts Used")
add_p("The tool applies multiple diverse concepts including:")
add_bullet("Classes and Object-Oriented Management Layers")
add_bullet("Functional and Data Aggregation Pipelines")
add_bullet("Decorators and View Controllers")
add_bullet("Relational SQL and Python bridging")
add_bullet("Pandas Matrix and Series Math operations")
add_bullet("Try, Except handling")
add_bullet("HTML, CSS standard injections for UI modifications")

doc_pdf.build(elements)
print(f"PDF document saved to: {PDF_PATH}")
