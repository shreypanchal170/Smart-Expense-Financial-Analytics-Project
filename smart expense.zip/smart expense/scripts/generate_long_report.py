import os
import sys

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

DOCS_DIR = r"c:\Users\Admin\smart expense\docs"
os.makedirs(DOCS_DIR, exist_ok=True)
PDF_PATH = os.path.join(DOCS_DIR, "Smart_Expense_Expanded_Technical_Report.pdf")

print("Generating Highly Detailed PDF Document (.pdf)...")

doc_pdf = SimpleDocTemplate(
    PDF_PATH,
    pagesize=letter,
    leftMargin=45, rightMargin=45,
    topMargin=45, bottomMargin=45
)

styles = getSampleStyleSheet()
title_style = ParagraphStyle('TitleStyle', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=18, textColor=colors.HexColor("#0F172A"), leading=26, alignment=1)
h1_style = ParagraphStyle('H1Style', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=14, textColor=colors.HexColor("#0F172A"), leading=19, spaceBefore=14, spaceAfter=6)
h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=12, textColor=colors.HexColor("#0EA5E9"), leading=15, spaceBefore=10, spaceAfter=4)
body_style = ParagraphStyle('BodyStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=10, textColor=colors.HexColor("#334155"), leading=14, spaceAfter=6)
bullet_style = ParagraphStyle('BulletStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=10, textColor=colors.HexColor("#1E293B"), leading=14, spaceAfter=4)
code_style = ParagraphStyle('CodeStyle', parent=styles['Code'], fontName='Courier', fontSize=9, textColor=colors.HexColor("#b91c1c"), leading=12, spaceAfter=6)

elements = []

def add_h1(text): elements.append(Paragraph(text, h1_style))
def add_h2(text): elements.append(Paragraph(text, h2_style))
def add_p(text): elements.append(Paragraph(text, body_style))
def add_bullet(text): elements.append(Paragraph(f"• {text}", bullet_style))
def add_code(text): elements.append(Paragraph(text, code_style))

# Title
elements.append(Paragraph("Comprehensive Technical Report: Smart Expense & Financial Analytics System", title_style))
elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0EA5E9"), spaceAfter=12))

# 1. Project Overview
add_h1("1. Project Overview")
add_p("The project is a professional, desktop and web-based Smart Expense & Financial Analytics System developed primarily in Python 3.11+. The core objective of the application is to empower users to manage their personal finance and provide real-time, institution-level analytics without relying on any external cloud infrastructure or bank logins.")
add_p("The user engages with a modern, dark-themed interactive dashboard to enter their daily expenses, track their income streams, and monitor custom-defined category budgets. The application downloads and processes this transactional data, validates it, and securely saves it into a local SQLite database.")
add_p("Unlike a simple tracker, this application is equipped with an integrated Machine Learning layer and data analytics engine. It computes basic, monthly, and yearly statistics, identifies anomalous or suspicious spending via an Isolation Forest algorithm, fits normal distribution probability curves, and leverages Plotly, Matplotlib, and Seaborn to generate highly interactive data visualizations.")
add_p("<b>Deep Dive Features:</b>")
add_bullet("Encrypted Local Storage: Enter a transaction and have it stored securely locally.")
add_bullet("Data Inspection: Inspect transaction records to detect missing values and outliers.")
add_bullet("Category Budgeting: Compare monthly spending thresholds vs real-time consumption.")
add_bullet("6-Stage Data Cleaning: Standardize, impute, parse dates, and remove duplicates automatically.")
add_bullet("Machine Learning: Anomaly detection scans parameters via Isolation Forest logic.")
add_bullet("KPI Generations: Real-time rendering of Net Balance, Total Spends, and Anomaly logs.")
add_bullet("CSV Interactions: Export/Import raw memory array data structures natively.")
add_bullet("Advanced Visualization: Render multi-layer statistical matrix maps and reactive pie charts.")

# 2. Technologies Used
add_h1("2. Core Technologies Used")
t_data = [
    [Paragraph("<b>Technology</b>", bullet_style), Paragraph("<b>Detailed Context</b>", bullet_style)],
    [Paragraph("Python", bullet_style), Paragraph("The backend execution context processing all logic and arithmetic via Python 3.11+.", bullet_style)],
    [Paragraph("Streamlit", bullet_style), Paragraph("Serves as the responsive frontend, generating sidebars, forms, metric cards, and plot canvases.", bullet_style)],
    [Paragraph("SQLite3", bullet_style), Paragraph("Acts as the transactional storage layer containing connected relational data tables.", bullet_style)],
    [Paragraph("Pandas", bullet_style), Paragraph("Manages data retrieval, heavy aggregations, pivoting, and numeric imputations.", bullet_style)],
    [Paragraph("Plotly/Seaborn", bullet_style), Paragraph("Creates responsive SVG/WebGL charts and matrix mappings (KDE distribution shapes).", bullet_style)],
    [Paragraph("Scikit-Learn", bullet_style), Paragraph("Implements unsupervised IsolationForest decision trees to flag structural deviations.", bullet_style)],
    [Paragraph("SciPy", bullet_style), Paragraph("Performs t-tests, standard-error validations, and Gaussian probability estimations.", bullet_style)]
]
pdf_table1 = Table(t_data, colWidths=[120, 310])
pdf_table1.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#f1f5f9")),
    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
]))
elements.append(pdf_table1)
elements.append(Spacer(1, 10))

# 3. How the Project Works
add_h1("3. Comprehensive Architecture & Data Flow")
add_p("The functional flow operates on a Model-View-Controller optimized sequence:")
add_p("1. <b>User Request (View)</b>: Launch via app.py, navigation sidebar routing invoked.")
add_p("2. <b>Data Input (View)</b>: User fills standard fields like Date, Amount, Category in UI.")
add_p("3. <b>Validation (Controller)</b>: `expense_manager.py` sanitizes textual and floating inputs.")
add_p("4. <b>Persistence (Model)</b>: Parameterized query triggers `INSERT INTO` SQLite structures.")
add_p("5. <b>Data Pre-processing (Controller)</b>: The internal pipeline normalizes object arrays.")
add_p("6. <b>Complex Computation (Controller)</b>: Metrics algorithms resolve IQR statistics.")
add_p("7. <b>Visualization Rendering (Controller)</b>: Plotly builds reactive trace graph dictionaries.")
add_p("8. <b>Final Display (View)</b>: Component is drawn into Streamlit container wrapper modules.")

# 4. Project Libraries
add_h1("4. In-Depth Project Libraries")
add_h2("4.1 Streamlit (Frontend Rendering)")
add_p("Streamlit is the exclusive graphical package mapping python variables to browser HTML objects.")
add_bullet("st.set_page_config() established dark mode rules.")
add_bullet("st.sidebar encapsulates navigation objects.")
add_bullet("st.columns(N) creates grid layouts dividing dashboard modules.")

add_h2("4.2 SQLite3 (Data Storage)")
add_p("The system relies entirely on parameterized cursors protecting data against SQL Injection protocols.")
add_code("cursor.execute('''INSERT INTO expenses (date, amount, category, payment_method) VALUES (?,?,?,?)''', (d_string, float_val, cat, pay))")

add_h2("4.3 Pandas (Data Processing Engine)")
add_p("Pandas serves as the central API data intermediary. SQL data sets transfer structurally into `pd.DataFrame` containers natively via `pd.read_sql_query` logic mapping elements sequentially.")
add_bullet("pd.to_datetime() parses chronological dates enabling dynamic month grouping.")
add_bullet("df.groupby() segregates row constraints based on matched variable signatures.")

add_h2("4.4 Plotly (Interactive Web Graphics)")
add_p("Plotly Express constructs highly scalable web plots utilizing dictionary based hierarchy commands allowing deep CSS mapping configurations.")

add_h2("4.5 Scikit-Learn (Unsupervised Machine Learning AI)")
add_p("Executing directly inside `anomaly_detection.py`, the AI logic flags transactions deviating severely from usual routine habits via statistical grouping tree structures mapping path parameters.")
add_code("model = IsolationForest(contamination=0.05, random_state=42)")

# 5. Main Design Architecture
add_h1("5. Main Application Structure Boundaries")
add_p("The script system runs on strict module boundaries keeping /pages_custom explicitly for UI routing and /analytics exclusively for pure mathematical formulas separating visual coupling.")

# 6. Program Starting Point
add_h1("6. Streamlit Engine Initializer Point")
add_p("The system processes explicitly from `app.py` directly loading Google CSS Font styling overrides.")
add_code("streamlit run app.py")

# 7. Automated Initialization Function 
add_h1("7. Internal Startup Process")
add_p("When loading, a sequence queries the core database arrays, testing table `COUNT(*)`. If completely void, the application imports static dataset placeholders populating dummy tables seamlessly for a perfect initial demonstration phase outputting metrics instantly.")

# 8. GUI Construction
add_h1("8. Extended GUI Array Configuration")
add_p("The left-sided vertical menu orchestrates standard navigation flows across highly detailed metrics boards containing Dashboard KPIs, Management parameters, Anomaly tools, CSV bridges, and raw Admin controls performing destructive drops.")

# 9. Form Transaction Input Processing
add_h1("9. Web Form Event Routing")
add_p("Input systems trigger UI pause parameters utilizing explicit explicit block scoping via Python object context manager wrappers preserving application memory limits until submit sequences occur.")
add_code("with st.form('transaction_block'):")
add_code("    sum_val = st.number_input('Total Cost', min_value=0.01)")

# 10. Extracting Data Subsets
add_h1("10. GroupBy Mathematical Matrices")
add_p("Answering questions requires sub-segmenting linear table arrays extracting flat hierarchies mapping arrays properly for Heatmaps mapping Days vs Months.")
add_code("pivot_data = df.groupby(['category', 'month'])['amount'].sum()")

# 11. Exception Handling Boundaries
add_h1("11. Application Safety Errors")
add_p("Critical SQL connections wrap under explicit Try/Except sequences capturing specific `sqlite3.OperationalError` handling file locks dynamically rejecting failure cascades preserving continuous user interface uptime logic flows.")

# 12. Advanced Data Cleaning Stages
add_h1("12. Linear Preprocessing Tasks")
add_p("Data pipelines correct user input parsing strings uniformly processing `.str.title()` commands standardizing inputs sequentially whilst executing distinct `drop_duplicates` dropping mathematical clones.")

# 13. Complex KPI Display Rendering
add_h1("13. Streamlit Display Invocations")
add_p("Data processes native dashboard structures utilizing metric objects assigning raw dictionary index sums dynamically applying percentage margin markers reacting sequentially on delta assignments mapped explicitly via logic flows.")

# 14. Validation Notifications
add_h1("14. Display Response Signals")
add_p("Status mechanisms return state alerts rendering explicitly visual success, warning, or error messages directly onto the screen without alerting the database components asynchronously.")

# 15. The Output Visualization Engine
add_h1("15. Graph Dictionary Constructions")
add_p("Functions encapsulate complex plotting elements returning standard Figure objects supporting transparent native HTML layouts allowing perfect GUI embedding protocols interacting beautifully within dark themes.")

# 16. CSV File Operations
add_h1("16. Raw Byte File Conversions")
add_p("Standard operations process string lists executing utf-8 explicit string byte encoding parsing natively into CSV stream modules allowing instant local file dumping handling huge row arrays efficiently.")

# 17. Deep Statistical Math Implementations
add_h1("17. SciPy Calculus Methods")
add_p("Mathematical logic resolves explicit 95% Confidence Interval limits evaluating theoretical distribution standard-errors matching bounds against true variables.")
add_code("ci_margin = std_error * stats.t.ppf((1 + 0.95) / 2., len(df)-1)")

# 18. Vital Python Constructs
add_h1("18. Master-Level Python Formats")
add_p("The application utilizes advanced Python methods incorporating List Comprehensions parsing iterative rows safely, Dict Row Factories standardizing SQL variable keys dictating array extraction patterns and implementing strict Object Context Management mapping bounds perfectly within physical limitations resolving variables natively without memory leak hazards handling high density arrays correctly via garbage collectors.")

doc_pdf.build(elements)
print(f"Expanded Detailed PDF document saved to: {PDF_PATH}")
