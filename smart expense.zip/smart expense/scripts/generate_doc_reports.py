import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

DOCS_DIR = r"c:\Users\Admin\smart expense\docs"
os.makedirs(DOCS_DIR, exist_ok=True)
DOCX_PATH = os.path.join(DOCS_DIR, "Smart_Expense_Code_Report.docx")
PDF_PATH = os.path.join(DOCS_DIR, "Smart_Expense_Code_Report.pdf")

print("Generating Word Document (.docx)...")

doc = Document()

# Set Standard Margins
for section in doc.sections:
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

# Styling Helpers
def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def add_h1(text):
    h = doc.add_heading(text, level=1)
    h.paragraph_format.space_before = Pt(18)
    h.paragraph_format.space_after = Pt(6)
    for run in h.runs:
        run.font.name = "Calibri"
        run.font.color.rgb = RGBColor(15, 23, 42)
        run.font.bold = True
    return h

def add_h2(text):
    h = doc.add_heading(text, level=2)
    h.paragraph_format.space_before = Pt(14)
    h.paragraph_format.space_after = Pt(4)
    for run in h.runs:
        run.font.name = "Calibri"
        run.font.color.rgb = RGBColor(14, 165, 233)
        run.font.bold = True
    return h

def add_p(text, bold_prefix="", italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    if bold_prefix:
        r_pre = p.add_run(bold_prefix)
        r_pre.bold = True
        r_pre.font.name = "Calibri"
    r_text = p.add_run(text)
    r_text.font.name = "Calibri"
    r_text.italic = italic
    return p

def add_bullet(bold_title, desc):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.15
    r_bold = p.add_run(bold_title)
    r_bold.bold = True
    r_bold.font.name = "Calibri"
    r_bold.font.color.rgb = RGBColor(15, 23, 42)
    r_desc = p.add_run(desc)
    r_desc.font.name = "Calibri"
    return p

# Document Header / Title
title_p = doc.add_paragraph()
title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run_title = title_p.add_run("Smart Expense & Financial Analytics System")
run_title.font.name = "Calibri"
run_title.font.size = Pt(24)
run_title.font.bold = True
run_title.font.color.rgb = RGBColor(15, 23, 42)

sub_p = doc.add_paragraph()
sub_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run_sub = sub_p.add_run("Technical Code Report & Imported Libraries Reference Guide")
run_sub.font.name = "Calibri"
run_sub.font.size = Pt(13)
run_sub.font.italic = True
run_sub.font.color.rgb = RGBColor(14, 165, 233)

meta_p = doc.add_paragraph()
meta_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run_meta = meta_p.add_run("Version 1.0.0  |  Python 3.11+  |  Streamlit, Pandas, Plotly, SciPy, Scikit-Learn, SQLite3")
run_meta.font.size = Pt(9.5)
run_meta.font.color.rgb = RGBColor(100, 116, 139)

doc.add_paragraph().paragraph_format.space_after = Pt(8)

# SECTION 1: EXECUTIVE SUMMARY
add_h1("1. Executive System Overview")
add_p("The Smart Expense & Financial Analytics System is a production-grade personal finance management and analytical desktop application built in Python 3.11+. The system empowers users to track daily expenses, log income streams, set monthly category budgets with automated overspend alerts, run a 6-stage data cleaning pipeline, execute machine learning anomaly detection, and perform financial analytics.")
add_p("Security & Data Privacy: ", bold_prefix="Local Architecture Model: ")
add_p("All application data is stored 100% locally inside a parameterized SQLite 3 database (smart_expense.db). It requires zero third-party cloud API keys, external database servers, or financial institution logins, guaranteeing complete data sovereignty and privacy.")

# SECTION 2: IMPORTED LIBRARIES BULLET OVERVIEW
add_h1("2. Imported Libraries Overview & Usage Descriptions")
add_p("Below is the comprehensive breakdown of every Python library imported across the Smart Expense codebase, detailing its technical description, primary role, and specific bullet-point usage in the application:")

imported_libs_details = [
    ("1. Streamlit (`import streamlit as st`)",
     "An open-source Python framework for rapidly creating custom web UI applications.",
     [
         "Renders the interactive dark-themed web interface, expandable sidebar navigation, and radio menu routing across 8 page views.",
         "Displays real-time executive KPI metric cards, data tables, select boxes, date pickers, forms, and alerts (success, info, warning, error).",
         "Manages UI reactive state, triggers dynamic app reruns (`st.rerun()`), embeds Plotly/Seaborn charts, and handles downloadable CSV reports."
     ]),

    ("2. Pandas (`import pandas as pd`)",
     "The primary data analysis, manipulation, and tabular DataFrame library for Python.",
     [
         "Executes SQL queries directly into structured DataFrames using `pd.read_sql_query()`.",
         "Performs complex multi-column group-by aggregations (`df.groupby()`), cumulative spending sums (`cumsum()`), and pivot tables.",
         "Powers the automated 6-stage Data Cleaning pipeline (missing value imputation, title-case normalization, date parsing, duplicate dropping)."
     ]),

    ("3. NumPy (`import numpy as np`)",
     "High-performance vectorized numerical computation library.",
     [
         "Provides conditional array logic (`np.where()`) to assign anomaly status flags and human-readable explanation strings.",
         "Generates evenly-spaced linear numerical point arrays (`np.linspace()`) for normal probability distribution curve fitting.",
         "Handles missing numerical cell values and NaN replacements (`np.nan`) during data cleaning."
     ]),

    ("4. Plotly Express & Plotly Graph Objects (`import plotly.express as px`, `import plotly.graph_objects as go`)",
     "High-definition interactive web chart generation library.",
     [
         "Renders interactive Donut Pie charts (`px.pie`), Histograms (`px.histogram`), Box Plots (`px.box`), and 2D Heatmaps (`px.imshow`).",
         "Constructs multi-trace line charts (`go.Scatter`) comparing daily spending against cumulative financial growth.",
         "Renders grouped bar charts (`go.Bar`) for monthly cash flow comparisons (Income vs Expense)."
     ]),

    ("5. SciPy Stats (`import scipy.stats as stats`)",
     "Advanced scientific computing and statistical inference package.",
     [
         "Calculates Standard Error of the Mean (`stats.sem`) and Student's t-distribution critical values (`stats.t.ppf`) for 95% Confidence Intervals.",
         "Runs One-Sample Hypothesis t-tests (`stats.ttest_1samp`) to evaluate spending against benchmark targets.",
         "Generates theoretical Gaussian Normal Probability Density Function curves (`stats.norm.pdf`)."
     ]),

    ("6. Seaborn (`import seaborn as sns`)",
     "Statistical data visualization library built on top of Matplotlib.",
     [
         "Plots empirical expense Kernel Density Estimation (KDE) distribution curves (`sns.histplot`).",
         "Renders horizontal category spending bar charts styled with curated color palettes (`sns.barplot`)."
     ]),

    ("7. Matplotlib Pyplot (`import matplotlib.pyplot as plt`)",
     "Core 2D plotting library providing figure canvas control.",
     [
         "Creates figure and axis handles (`plt.subplots()`) for static statistical plots.",
         "Renders static Seaborn visual objects directly inside Streamlit using `st.pyplot(fig)`."
     ]),

    ("8. Scikit-Learn Isolation Forest (`from sklearn.ensemble import IsolationForest`)",
     "Unsupervised ensemble machine learning algorithm for anomaly detection.",
     [
         "Trains decision tree forests to isolate unusual expense transactions based on tree depth path lengths.",
         "Predicts anomaly status (`-1` for outlier, `1` for normal) and generates decision boundary anomaly scores."
     ]),

    ("9. SQLite 3 (`import sqlite3`)",
     "Built-in relational database engine for local persistent data storage.",
     [
         "Manages the local relational database file `smart_expense.db` with ACID transaction support.",
         "Executes parameterized SQL queries to prevent SQL injection vulnerabilities.",
         "Enables `sqlite3.Row` factory for dictionary-style database row access."
     ]),

    ("10. Datetime & Timedelta (`from datetime import datetime, timedelta`)",
     "Standard Python library for date arithmetic, formatting, and parsing.",
     [
         "Computes dynamic date range bounds ('Today', 'This Week', 'This Month', 'Last Month', 'Last 90 Days').",
         "Parses and formats date strings (`%Y-%m-%d`, `%Y-%m`) for database queries and group-by aggregations."
     ]),

    ("11. Unittest (`import unittest`)",
     "Automated unit and integration testing framework.",
     [
         "Executes 7 unit tests verifying DB setup, input validation, CRUD workflows, budget tracking, data cleaning, statistics, and ML models."
     ])
]

for title, overview, bullets in imported_libs_details:
    add_h2(title)
    add_p(overview, italic=True)
    for b in bullets:
        add_bullet("• ", b)

# SECTION 3: FUNCTION REFERENCE MATRIX
add_h1("3. Third-Party Library & Function Summary Matrix")

lib_table = doc.add_table(rows=1, cols=4)
lib_table.alignment = WD_TABLE_ALIGNMENT.CENTER
hdr_cells = lib_table.rows[0].cells
headers = ["Library", "Version", "Role & Application Purpose", "Specific Functions & Classes Used"]
for i, h in enumerate(headers):
    hdr_cells[i].text = h
    set_cell_background(hdr_cells[i], "0F172A")
    p = hdr_cells[i].paragraphs[0]
    p.runs[0].font.color.rgb = RGBColor(255, 255, 255)
    p.runs[0].font.bold = True

libraries_data = [
    ("streamlit", "^1.30.0", "Web UI Framework & Dashboard Engine", "st.set_page_config(), st.markdown(), st.sidebar(), st.radio(), st.columns(), st.metric(), st.dataframe(), st.selectbox(), st.text_input(), st.number_input(), st.date_input(), st.form(), st.button(), st.plotly_chart(), st.pyplot(), st.download_button(), st.file_uploader(), st.progress(), st.rerun()"),
    ("pandas", "^2.1.0", "Data Processing & DataFrame Manipulation", "pd.DataFrame(), pd.read_sql_query(), pd.read_csv(), pd.to_csv(), pd.to_datetime(), pd.to_numeric(), df.isnull(), df.duplicated(), df.drop_duplicates(), df.dropna(), df.fillna(), df.groupby(), df.agg(), pd.merge(), df.pivot_table(), series.cumsum(), series.quantile(), series.skew(), series.kurtosis(), series.mode()"),
    ("numpy", "^1.26.0", "Vectorized Numerical Computing", "np.where(), np.linspace(), np.isnan(), np.mean(), np.std(), np.array()"),
    ("plotly.express", "^5.18.0", "High-Level Interactive Visualizations", "px.pie(), px.histogram(), px.box(), px.imshow(), px.colors.qualitative.Pastel"),
    ("plotly.graph_objects", "^5.18.0", "Custom Low-Level Graph Traces", "go.Figure(), go.Scatter(), go.Bar(), fig.update_layout(), fig.update_traces(), fig.add_trace(), fig.add_annotation()"),
    ("scipy.stats", "^1.11.0", "Inferential & Probabilistic Statistics", "stats.sem(), stats.t.ppf(), stats.ttest_1samp(), stats.norm.pdf()"),
    ("seaborn", "^0.13.0", "Statistical Plotting & Density Estimation", "sns.set_theme(), sns.histplot(), sns.barplot()"),
    ("matplotlib.pyplot", "^3.8.0", "Plot Rendering Canvas Handles", "plt.subplots(), plt.tight_layout(), ax.text(), ax.plot(), ax.legend()"),
    ("scikit-learn", "^1.3.0", "Machine Learning Anomaly Detection", "IsolationForest(contamination, random_state).fit_predict(), decision_function()"),
    ("sqlite3", "Standard Lib", "Local Relational Storage Engine", "sqlite3.connect(), sqlite3.Row, conn.cursor(), cursor.execute(), cursor.executescript(), cursor.fetchall(), cursor.fetchone(), conn.commit()")
]

for row_idx, data in enumerate(libraries_data):
    row_cells = lib_table.add_row().cells
    bg_color = "F8FAFC" if row_idx % 2 == 0 else "FFFFFF"
    for i, val in enumerate(data):
        row_cells[i].text = val
        set_cell_background(row_cells[i], bg_color)
        p = row_cells[i].paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        p.runs[0].font.size = Pt(8.5)

# SECTION 4: CODE FUNCTION REFERENCE BY MODULE
add_h1("4. Detailed Function-by-Function Code Reference")

modules_info = [
    ("4.1 Database Management Layer (database/db_manager.py)", [
        ("DatabaseManager.__init__(db_path: str)", "Constructor. Initializes SQLite database path and triggers schema initialization."),
        ("get_connection() -> sqlite3.Connection", "Creates thread-safe connection with check_same_thread=False and sqlite3.Row factory."),
        ("_init_db()", "Reads schema.sql and executes DDL script to create tables."),
        ("execute_query(query: str, params: Tuple = ()) -> int", "Executes parameterized INSERT, UPDATE, DELETE queries. Returns lastrowid."),
        ("fetch_all(query: str, params: Tuple = ()) -> List[Dict]", "Executes SELECT query and returns rows as list of dictionaries."),
        ("fetch_one(query: str, params: Tuple = ()) -> Optional[Dict]", "Fetches single matching row as dictionary."),
        ("fetch_dataframe(query: str, params: Tuple = ()) -> pd.DataFrame", "Loads query result directly into Pandas DataFrame using pd.read_sql_query."),
        ("clear_database()", "Resets transactional data in expenses, income, and budgets tables.")
    ]),
    ("4.2 Expense Management Module (modules/expense_manager.py)", [
        ("validate_expense_input(amount, date, category, payment_method)", "Validates amount > 0, YYYY-MM-DD date format, and non-empty category."),
        ("add_expense(date, amount, category, payment_method, description, notes)", "Inserts new expense transaction via parameterized SQL."),
        ("get_expenses_df(start_date, end_date, category, payment_method, search_query)", "Queries expenses with dynamic multi-criteria SQL filters."),
        ("update_expense(expense_id, date, amount, category, payment_method, description, notes)", "Updates existing expense record."),
        ("delete_expense(expense_id: int)", "Removes expense record permanently.")
    ]),
    ("4.3 Income Management Module (modules/income_manager.py)", [
        ("validate_income_input(amount, date, source)", "Validates positive amount, date, and non-empty source."),
        ("add_income(date, amount, source, description)", "Inserts new income transaction into database."),
        ("get_income_df(start_date, end_date, source, search_query)", "Queries income records with date bounds and filters."),
        ("update_income(...) & delete_income(income_id)", "Updates or deletes income record.")
    ]),
    ("4.4 Budget & Category Management (modules/budget_manager.py)", [
        ("set_budget(category, monthly_limit, month, year)", "Inserts or updates monthly category spending limits."),
        ("get_budget_status(month, year)", "Calculates total spend vs budget, utilization percentage, and alert status (On Track, Warning, Exceeded).")
    ]),
    ("4.5 Data Cleaning & Preprocessing (modules/data_cleaning.py)", [
        ("inspect_data_quality()", "Generates raw dataset quality metrics: total rows, missing cell counts, duplicates, invalid amounts."),
        ("clean_pipeline(drop_duplicates, fill_missing, normalize_categories)", "Runs 6-stage automated cleaning: trimming, title-case normalization, date parsing, invalid amount dropping, imputation, duplicate removal.")
    ]),
    ("4.6 Anomaly Detection Engine (modules/anomaly_detection.py)", [
        ("detect_outliers_iqr(df, column, k=1.5)", "Flags statistical anomalies using Interquartile Range rule (X > Q3 + 1.5*IQR)."),
        ("detect_outliers_zscore(df, column, threshold=2.0)", "Flags anomalies using Z-Score thresholding (|Z| > 2.0)."),
        ("detect_outliers_isolation_forest(df, column, contamination=0.05)", "Trains Scikit-Learn IsolationForest ML model to detect anomalous transactions.")
    ]),
    ("4.7 Statistical Analysis Module (modules/statistics_analysis.py)", [
        ("calculate_descriptive_stats(df, column)", "Computes mean, median, mode, range, variance, std dev, IQR, skewness, kurtosis."),
        ("calculate_confidence_interval(series, confidence=0.95)", "Computes 95% Confidence Interval for mean using Student's t-distribution."),
        ("run_one_sample_ttest(series, pop_mean)", "Executes One-Sample Hypothesis t-test against benchmark targets."),
        ("generate_normal_pdf_fit(series, num_points)", "Fits Gaussian Normal PDF curve (mu, sigma) over empirical data.")
    ]),
    ("4.8 Financial Analytics & Visualization Engine (analytics/)", [
        ("calculate_dashboard_kpis(start_date, end_date)", "Computes Total Income, Total Expenses, Net Balance, Daily Average, Highest Category, Transaction Count, Unusual Count."),
        ("create_category_pie_chart(df)", "Generates interactive Plotly Donut Chart for spending distribution."),
        ("create_daily_trend_line_chart(df)", "Generates multi-trace Plotly Line Chart for daily spending & cumulative sum."),
        ("create_income_vs_expense_bar_chart(exp_df, inc_df)", "Generates Plotly Grouped Bar Chart comparing monthly cash flow."),
        ("create_amount_histogram(df)", "Generates Plotly Histogram showing amount frequency distribution."),
        ("create_box_plot_outliers(df)", "Generates Plotly Box & Whisker plot for category outlier spread."),
        ("create_spending_heatmap(df)", "Generates Plotly Heatmap showing spend density by Day of Week vs Category."),
        ("generate_seaborn_statistical_plots(df)", "Generates Seaborn KDE distribution plot with normal PDF fit and category bar chart.")
    ])
]

for mod_title, func_list in modules_info:
    add_h2(mod_title)
    for fname, fdesc in func_list:
        add_p(fdesc, bold_prefix=f"• {fname}: ")

doc.save(DOCX_PATH)
print(f"Word document saved to: {DOCX_PATH}")

# GENERATE PDF REPORT
print("Generating PDF Document (.pdf)...")

doc_pdf = SimpleDocTemplate(
    PDF_PATH,
    pagesize=letter,
    leftMargin=45, rightMargin=45,
    topMargin=45, bottomMargin=45
)

styles = getSampleStyleSheet()
title_style = ParagraphStyle('TitleStyle', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=22, textColor=colors.HexColor("#0F172A"), leading=26, alignment=1)
subtitle_style = ParagraphStyle('SubStyle', parent=styles['Normal'], fontName='Helvetica-Oblique', fontSize=11, textColor=colors.HexColor("#0EA5E9"), leading=15, alignment=1)
h1_style = ParagraphStyle('H1Style', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=15, textColor=colors.HexColor("#0F172A"), leading=19, spaceBefore=14, spaceAfter=6)
h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=11, textColor=colors.HexColor("#0EA5E9"), leading=15, spaceBefore=10, spaceAfter=4)
body_style = ParagraphStyle('BodyStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=9.5, textColor=colors.HexColor("#334155"), leading=13.5, spaceAfter=4)
bullet_style = ParagraphStyle('BulletStyle', parent=styles['BodyText'], fontName='Helvetica', fontSize=8.5, textColor=colors.HexColor("#1E293B"), leading=12, spaceAfter=3)

elements = []

# Title & Header
elements.append(Paragraph("Smart Expense & Financial Analytics System", title_style))
elements.append(Spacer(1, 3))
elements.append(Paragraph("Technical Code Report & Imported Libraries Reference Guide", subtitle_style))
elements.append(Spacer(1, 10))
elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0EA5E9"), spaceAfter=12))

# Section 1
elements.append(Paragraph("1. Executive System Overview", h1_style))
elements.append(Paragraph("The <b>Smart Expense & Financial Analytics System</b> is a personal finance management and data analytics platform written in Python 3.11+. It empowers users to track expenses, log income streams, set monthly budgets with overspend alerts, run a 6-stage data cleaning pipeline, execute machine learning anomaly detection, and perform financial analytics.", body_style))
elements.append(Paragraph("<b>Local Security Model:</b> All application data is stored locally in a parameterized SQLite 3 database (smart_expense.db), requiring zero external cloud dependencies or bank credentials.", body_style))

# Section 2: Bullet Point Library Overview
elements.append(Paragraph("2. Imported Libraries Overview & Usage Descriptions", h1_style))
elements.append(Paragraph("Below is the comprehensive breakdown of every library imported across the Smart Expense codebase:", body_style))

for title, overview, bullets in imported_libs_details:
    elements.append(Paragraph(title, h2_style))
    elements.append(Paragraph(f"<i>{overview}</i>", body_style))
    for b in bullets:
        elements.append(Paragraph(f"<b>• </b>{b}", bullet_style))

# Section 3: Summary Matrix
elements.append(Spacer(1, 10))
elements.append(Paragraph("3. Third-Party Library & Function Summary Matrix", h1_style))

t_data = [["Library", "Version", "Role & Application Purpose", "Functions / Classes Used"]]
for lib, ver, role, funcs in libraries_data:
    t_data.append([
        Paragraph(f"<b>{lib}</b>", bullet_style),
        Paragraph(ver, bullet_style),
        Paragraph(role, bullet_style),
        Paragraph(funcs, bullet_style)
    ])

pdf_table1 = Table(t_data, colWidths=[80, 50, 150, 242])
pdf_table1.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#0F172A")),
    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
    ('ALIGN', (0,0), (-1,-1), 'LEFT'),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
]))
elements.append(pdf_table1)

# Section 4: Detailed Function Reference
elements.append(Spacer(1, 10))
elements.append(Paragraph("4. Detailed Function-by-Function Code Reference", h1_style))

for mod_title, func_list in modules_info:
    elements.append(Paragraph(mod_title, h2_style))
    for fname, fdesc in func_list:
        p_text = f"<b>• {fname}</b>: {fdesc}"
        elements.append(Paragraph(p_text, bullet_style))

doc_pdf.build(elements)
print(f"PDF document saved to: {PDF_PATH}")
print("SUCCESS!")
