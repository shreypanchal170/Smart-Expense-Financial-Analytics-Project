"""
Budget Management Module for Smart Expense & Financial Analytics System.
Tracks category budgets, spending thresholds, utilization rates, and alerts.
"""

from datetime import datetime
import pandas as pd
from typing import List, Dict, Any, Tuple
from database.db_manager import db

def set_budget(category: str, monthly_limit: float, month: int, year: int) -> Tuple[bool, str]:
    """Set or update monthly budget limit for a category."""
    if monthly_limit < 0:
        return False, "Budget limit cannot be negative."
    if not (1 <= month <= 12):
        return False, "Month must be between 1 and 12."
    if year < 2000:
        return False, "Invalid year."

    query = """
    INSERT INTO budgets (category, monthly_limit, month, year)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(category, month, year) DO UPDATE SET monthly_limit = excluded.monthly_limit
    """
    db.execute_query(query, (category, float(monthly_limit), month, year))
    return True, f"Budget limit for {category} set to ₹{monthly_limit:,.2f} for {month}/{year}."

def get_budgets(month: int, year: int) -> pd.DataFrame:
    """Fetch budgets for a specific month and year."""
    query = "SELECT * FROM budgets WHERE month = ? AND year = ? ORDER BY category ASC"
    return db.fetch_dataframe(query, (month, year))

def get_budget_status(month: int, year: int) -> List[Dict[str, Any]]:
    """
    Calculate spent amount, remaining budget, utilization percentage, and alert status
    for each configured budget category in a given month and year.
    """
    start_date = f"{year:04d}-{month:02d}-01"
    if month == 12:
        end_date = f"{year+1:04d}-01-01"
    else:
        end_date = f"{year:04d}-{month+1:02d}-01"

    # Fetch configured budgets
    budgets_df = get_budgets(month, year)
    if budgets_df.empty:
        return []

    # Fetch expenses for the month
    expense_query = """
    SELECT category, SUM(amount) as spent
    FROM expenses
    WHERE date >= ? AND date < ?
    GROUP BY category
    """
    spent_df = db.fetch_dataframe(expense_query, (start_date, end_date))
    spent_dict = dict(zip(spent_df["category"], spent_df["spent"])) if not spent_df.empty else {}

    results = []
    for _, row in budgets_df.iterrows():
        cat = row["category"]
        limit = float(row["monthly_limit"])
        spent = float(spent_dict.get(cat, 0.0))
        remaining = limit - spent
        pct = (spent / limit * 100.0) if limit > 0 else 0.0

        if pct >= 100.0:
            status = "Exceeded"
            alert_level = "danger"
        elif pct >= 80.0:
            status = "Warning"
            alert_level = "warning"
        else:
            status = "On Track"
            alert_level = "success"

        results.append({
            "id": row["id"],
            "category": cat,
            "monthly_limit": limit,
            "spent": spent,
            "remaining": remaining,
            "utilization_pct": round(pct, 1),
            "status": status,
            "alert_level": alert_level
        })

    return results

def delete_budget(budget_id: int) -> bool:
    """Delete a budget entry."""
    query = "DELETE FROM budgets WHERE id = ?"
    db.execute_query(query, (budget_id,))
    return True
