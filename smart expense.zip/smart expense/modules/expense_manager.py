"""
Expense Management Module for Smart Expense & Financial Analytics System.
Handles CRUD operations, data validation, filtering, and sorting for expenses.
"""

from datetime import datetime
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
from database.db_manager import db

PAYMENT_METHODS = ["UPI", "Credit Card", "Debit Card", "Cash", "Net Banking"]

def validate_expense_input(amount: float, date_str: str, category: str, payment_method: str) -> Tuple[bool, str]:
    """Validate expense entry inputs."""
    if amount is None or amount <= 0:
        return False, "Amount must be greater than zero."
    if not category or not category.strip():
        return False, "Category must be selected."
    if not payment_method or not payment_method.strip():
        return False, "Payment method must be selected."
    
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except (ValueError, TypeError):
        return False, "Invalid date format. Expected YYYY-MM-DD."
        
    return True, "Success"

def add_expense(date: str, amount: float, category: str, payment_method: str, description: str = "", notes: str = "") -> Tuple[bool, str]:
    """Add a new expense transaction."""
    valid, msg = validate_expense_input(amount, date, category, payment_method)
    if not valid:
        return False, msg

    query = """
    INSERT INTO expenses (date, amount, category, payment_method, description, notes)
    VALUES (?, ?, ?, ?, ?, ?)
    """
    db.execute_query(query, (date, float(amount), category.strip(), payment_method.strip(), description.strip(), notes.strip()))
    return True, "Expense recorded successfully!"

def update_expense(expense_id: int, date: str, amount: float, category: str, payment_method: str, description: str = "", notes: str = "") -> Tuple[bool, str]:
    """Update an existing expense transaction."""
    valid, msg = validate_expense_input(amount, date, category, payment_method)
    if not valid:
        return False, msg

    query = """
    UPDATE expenses
    SET date = ?, amount = ?, category = ?, payment_method = ?, description = ?, notes = ?
    WHERE id = ?
    """
    db.execute_query(query, (date, float(amount), category.strip(), payment_method.strip(), description.strip(), notes.strip(), expense_id))
    return True, "Expense updated successfully!"

def delete_expense(expense_id: int) -> Tuple[bool, str]:
    """Delete an expense by ID."""
    query = "DELETE FROM expenses WHERE id = ?"
    db.execute_query(query, (expense_id,))
    return True, "Expense deleted successfully!"

def get_expense_by_id(expense_id: int) -> Optional[Dict[str, Any]]:
    """Fetch single expense by ID."""
    query = "SELECT * FROM expenses WHERE id = ?"
    return db.fetch_one(query, (expense_id,))

def get_expenses_df(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    categories: Optional[List[str]] = None,
    payment_methods: Optional[List[str]] = None,
    search_query: Optional[str] = None,
    sort_by: str = "date",
    ascending: bool = False
) -> pd.DataFrame:
    """Fetch expenses DataFrame with dynamic filtering, searching, and sorting."""
    conditions = ["1=1"]
    params: List[Any] = []

    if start_date:
        conditions.append("date >= ?")
        params.append(start_date)
    if end_date:
        conditions.append("date <= ?")
        params.append(end_date)
    if categories:
        placeholders = ",".join(["?"] * len(categories))
        conditions.append(f"category IN ({placeholders})")
        params.extend(categories)
    if payment_methods:
        placeholders = ",".join(["?"] * len(payment_methods))
        conditions.append(f"payment_method IN ({placeholders})")
        params.extend(payment_methods)
    if search_query and search_query.strip():
        conditions.append("(description LIKE ? OR notes LIKE ? OR category LIKE ?)")
        pattern = f"%{search_query.strip()}%"
        params.extend([pattern, pattern, pattern])

    valid_sort_columns = {"date": "date", "amount": "amount", "category": "category", "id": "id"}
    sort_col = valid_sort_columns.get(sort_by, "date")
    order = "ASC" if ascending else "DESC"

    where_clause = " AND ".join(conditions)
    query = f"SELECT * FROM expenses WHERE {where_clause} ORDER BY {sort_col} {order}, id {order}"

    df = db.fetch_dataframe(query, tuple(params))
    if not df.empty and "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    return df
