"""
CSV Handling, Report Generation & Data Backup Module for Smart Expense System.
Handles CSV importing, column schema validation, deduplication, error logging, and exporting reports.
"""

import os
import io
import pandas as pd
from typing import Dict, Any, Tuple, Optional
from database.db_manager import db
from modules.expense_manager import validate_expense_input
from modules.income_manager import validate_income_input

EXPENSE_CSV_COLUMNS = {"date", "amount", "category", "payment_method"}
INCOME_CSV_COLUMNS = {"date", "amount", "source"}

def import_expenses_from_csv(file_obj, auto_clean: bool = True) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Import expense records from an uploaded CSV file.
    Validates schema, checks duplicates against existing DB records, and logs results.
    """
    try:
        df = pd.read_csv(file_obj)
    except Exception as e:
        return False, f"Failed to parse CSV file: {str(e)}", {}

    # Standardize column headers
    df.columns = [str(c).strip().lower() for c in df.columns]

    if not EXPENSE_CSV_COLUMNS.issubset(set(df.columns)):
        missing = EXPENSE_CSV_COLUMNS - set(df.columns)
        return False, f"Missing required CSV columns: {', '.join(missing)}. Required: {', '.join(EXPENSE_CSV_COLUMNS)}", {}

    imported_count = 0
    skipped_count = 0
    errors = []

    # Fetch existing expenses to avoid inserting exact duplicates
    existing_df = db.fetch_dataframe("SELECT date, amount, category, payment_method, description FROM expenses")

    for idx, row in df.iterrows():
        try:
            date_val = str(row.get("date", "")).strip()
            amount_val = float(row.get("amount", 0))
            cat_val = str(row.get("category", "")).strip()
            pm_val = str(row.get("payment_method", "UPI")).strip()
            desc_val = str(row.get("description", "")).strip() if "description" in row and pd.notna(row["description"]) else "Imported Expense"
            notes_val = str(row.get("notes", "")).strip() if "notes" in row and pd.notna(row["notes"]) else "CSV Import"

            # Input validation
            valid, msg = validate_expense_input(amount_val, date_val, cat_val, pm_val)
            if not valid:
                skipped_count += 1
                errors.append(f"Row {idx+2}: {msg}")
                continue

            # Duplicate check
            if not existing_df.empty:
                dup_mask = (
                    (existing_df["date"] == date_val) &
                    (existing_df["amount"] == amount_val) &
                    (existing_df["category"].str.lower() == cat_val.lower()) &
                    (existing_df["payment_method"].str.lower() == pm_val.lower())
                )
                if dup_mask.any():
                    skipped_count += 1
                    errors.append(f"Row {idx+2}: Duplicate record detected.")
                    continue

            # Insert into database
            query = "INSERT INTO expenses (date, amount, category, payment_method, description, notes) VALUES (?, ?, ?, ?, ?, ?)"
            db.execute_query(query, (date_val, amount_val, cat_val, pm_val, desc_val, notes_val))
            imported_count += 1

        except Exception as ex:
            skipped_count += 1
            errors.append(f"Row {idx+2}: {str(ex)}")

    summary = {
        "total_rows": len(df),
        "imported_count": imported_count,
        "skipped_count": skipped_count,
        "errors": errors[:10] # Top 10 errors
    }
    return True, f"Successfully imported {imported_count} records. ({skipped_count} skipped)", summary

def import_income_from_csv(file_obj) -> Tuple[bool, str, Dict[str, Any]]:
    """Import income records from an uploaded CSV file."""
    try:
        df = pd.read_csv(file_obj)
    except Exception as e:
        return False, f"Failed to parse CSV file: {str(e)}", {}

    df.columns = [str(c).strip().lower() for c in df.columns]

    if not INCOME_CSV_COLUMNS.issubset(set(df.columns)):
        missing = INCOME_CSV_COLUMNS - set(df.columns)
        return False, f"Missing required CSV columns: {', '.join(missing)}", {}

    imported_count = 0
    skipped_count = 0
    errors = []

    for idx, row in df.iterrows():
        try:
            date_val = str(row.get("date", "")).strip()
            amount_val = float(row.get("amount", 0))
            src_val = str(row.get("source", "")).strip()
            desc_val = str(row.get("description", "")).strip() if "description" in row and pd.notna(row["description"]) else "Imported Income"

            valid, msg = validate_income_input(amount_val, date_val, src_val)
            if not valid:
                skipped_count += 1
                errors.append(f"Row {idx+2}: {msg}")
                continue

            query = "INSERT INTO income (date, amount, source, description) VALUES (?, ?, ?, ?)"
            db.execute_query(query, (date_val, amount_val, src_val, desc_val))
            imported_count += 1

        except Exception as ex:
            skipped_count += 1
            errors.append(f"Row {idx+2}: {str(ex)}")

    summary = {
        "total_rows": len(df),
        "imported_count": imported_count,
        "skipped_count": skipped_count,
        "errors": errors[:10]
    }
    return True, f"Successfully imported {imported_count} income records.", summary

def export_to_csv(df: pd.DataFrame) -> str:
    """Convert a DataFrame into a CSV string for file downloads."""
    return df.to_csv(index=False)
