"""
Data Preprocessing & Cleaning Module for Smart Expense & Financial Analytics System.
Implements Data Preparation (missing value handling, duplicate removal,
normalization, outlier cleaning, before/after audit reports).
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple

class DataCleaner:
    def __init__(self, df: pd.DataFrame):
        self.raw_df = df.copy()
        self.cleaned_df = df.copy()
        self.audit_log = []

    def inspect_data_quality(self) -> Dict[str, Any]:
        """Generate comprehensive quality summary of raw dataset."""
        if self.raw_df.empty:
            return {"total_rows": 0, "missing_values": {}, "duplicates": 0, "invalid_amounts": 0}

        missing_counts = self.raw_df.isnull().sum().to_dict()
        dup_count = int(self.raw_df.duplicated(subset=["date", "amount", "category", "description"], keep=False).sum())
        
        invalid_amounts = 0
        if "amount" in self.raw_df.columns:
            invalid_amounts = int((pd.to_numeric(self.raw_df["amount"], errors="coerce") <= 0).sum())

        return {
            "total_rows": len(self.raw_df),
            "total_columns": len(self.raw_df.columns),
            "missing_values": missing_counts,
            "total_missing_cells": int(sum(missing_counts.values())),
            "duplicates": dup_count,
            "invalid_amounts": invalid_amounts
        }

    def clean_pipeline(self, drop_duplicates: bool = True, fill_missing: bool = True, normalize_categories: bool = True) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """Run standard data cleaning pipeline."""
        df = self.cleaned_df.copy()
        initial_len = len(df)
        logs = []

        # 1. Strip Whitespace from text columns
        text_cols = df.select_dtypes(include=["object"]).columns
        for col in text_cols:
            df[col] = df[col].astype(str).str.strip()
            # Restore True NaNs
            df[col] = df[col].replace(["nan", "None", ""], np.nan)

        # 2. Category Normalization (Title Case)
        if normalize_categories and "category" in df.columns:
            df["category"] = df["category"].str.title()
            logs.append("Normalized category text format to Title Case.")

        # 3. Date Formatting
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.strftime("%Y-%m-%d")
            na_dates = df["date"].isnull().sum()
            if na_dates > 0:
                df = df.dropna(subset=["date"])
                logs.append(f"Dropped {na_dates} rows with unparseable dates.")

        # 4. Numeric Amount Cleaning
        if "amount" in df.columns:
            df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
            invalid_amt_count = (df["amount"] <= 0) | (df["amount"].isnull())
            if invalid_amt_count.sum() > 0:
                df = df[~invalid_amt_count]
                logs.append(f"Removed {invalid_amt_count.sum()} records with non-positive/invalid amounts.")

        # 5. Missing Values Imputation / Handling
        if fill_missing:
            if "description" in df.columns:
                df["description"] = df["description"].fillna("General Expense")
            if "notes" in df.columns:
                df["notes"] = df["notes"].fillna("N/A")
            if "payment_method" in df.columns:
                df["payment_method"] = df["payment_method"].fillna("UPI")
            logs.append("Imputed missing text fields with default values.")

        # 6. Remove Duplicate Transactions
        if drop_duplicates:
            subset_cols = [c for c in ["date", "amount", "category", "description"] if c in df.columns]
            dups_before = df.duplicated(subset=subset_cols).sum()
            if dups_before > 0:
                df = df.drop_duplicates(subset=subset_cols, keep="first")
                logs.append(f"Removed {dups_before} duplicate transaction records.")

        self.cleaned_df = df
        summary = {
            "initial_rows": initial_len,
            "final_rows": len(df),
            "removed_rows": initial_len - len(df),
            "pipeline_logs": logs
        }
        return self.cleaned_df, summary
