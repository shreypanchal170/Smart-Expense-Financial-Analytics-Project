"""
Income Management Module for Smart Expense & Financial Analytics System.
Handles income records CRUD operations, input validation, and income-vs-expense metrics.
"""

from datetime import datetime
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
from database.db_manager import db

INCOME_SOURCES = ["Salary", "Allowance", "Freelance", "Scholarship", "Gift", "Other Income"]

def validate_income_input(amount: float, date_str: str, source: str) -> Tuple[bool, str]:
    """Validate income entry inputs."""
    if amount is None or amount <= 0:
        return False, "Amount must be greater than zero."
    if not source or not source.strip():
        return False, "Income source must be selected."
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except (ValueError, TypeError):
        return False, "Invalid date format. Expected YYYY-MM-DD."
    return True, "Success"

def add_income(date: str, amount: float, source: str, description: str = "") -> Tuple[bool, str]:
    """Add a new income transaction."""
    valid, msg = validate_income_input(amount, date, source)
    if not valid:
        return False, msg

    query = "INSERT INTO income (date, amount, source, description) VALUES (?, ?, ?, ?)"
    db.execute_query(query, (date, float(amount), source.strip(), description.strip()))
    return True, "Income recorded successfully!"

def update_income(income_id: int, date: str, amount: float, source: str, description: str = "") -> Tuple[bool, str]:
    """Update an existing income record."""
    valid, msg = validate_income_input(amount, date, source)
    if not valid:
        return False, msg

    query = "UPDATE income SET date = ?, amount = ?, source = ?, description = ? WHERE id = ?"
    db.execute_query(query, (date, float(amount), source.strip(), description.strip(), income_id))
    return True, "Income record updated successfully!"

def delete_income(income_id: int) -> Tuple[bool, str]:
    """Delete an income record."""
    query = "DELETE FROM income WHERE id = ?"
    db.execute_query(query, (income_id,))
    return True, "Income record deleted successfully!"

def get_income_by_id(income_id: int) -> Optional[Dict[str, Any]]:
    """Fetch single income record by ID."""
    query = "SELECT * FROM income WHERE id = ?"
    return db.fetch_one(query, (income_id,))

def get_income_df(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    sources: Optional[List[str]] = None,
    sort_by: str = "date",
    ascending: bool = False
) -> pd.DataFrame:
    """Fetch income records as DataFrame with filters."""
    conditions = ["1=1"]
    params: List[Any] = []

    if start_date:
        conditions.append("date >= ?")
        params.append(start_date)
    if end_date:
        conditions.append("date <= ?")
        params.append(end_date)
    if sources:
        placeholders = ",".join(["?"] * len(sources))
        conditions.append(f"source IN ({placeholders})")
        params.extend(sources)

    order = "ASC" if ascending else "DESC"
    where_clause = " AND ".join(conditions)
    query = f"SELECT * FROM income WHERE {where_clause} ORDER BY {sort_by} {order}, id {order}"

    df = db.fetch_dataframe(query, tuple(params))
    if not df.empty and "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    return df
