"""
Unusual Expense & Anomaly Detection Module for Smart Expense & Financial Analytics System.
Implements 3 detection techniques:
1. Interquartile Range (IQR) Rule
2. Z-Score Thresholding
3. Scikit-learn Isolation Forest ML Classifier
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
from sklearn.ensemble import IsolationForest

def detect_outliers_iqr(df: pd.DataFrame, column: str = "amount", k: float = 1.5) -> pd.DataFrame:
    """
    Detect unusual expenses using Interquartile Range (IQR) rule.
    Outlier condition: X > Q3 + k * IQR  or  X < Q1 - k * IQR
    """
    if df.empty or column not in df.columns:
        return df

    result_df = df.copy()
    series = result_df[column]
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    upper_bound = q3 + (k * iqr)
    lower_bound = q1 - (k * iqr)

    is_anomaly = (series > upper_bound) | (series < lower_bound)
    result_df["anomaly_method"] = "IQR Rule"
    result_df["is_anomaly"] = is_anomaly
    result_df["anomaly_status"] = np.where(is_anomaly, "Flagged", "Normal")
    
    # Detailed statistical explanation
    explanations = []
    for val in series:
        if val > upper_bound:
            explanations.append(f"Amount ₹{val:,.2f} exceeds upper limit ₹{upper_bound:,.2f} (Q3 + {k}×IQR)")
        elif val < lower_bound:
            explanations.append(f"Amount ₹{val:,.2f} below lower limit ₹{lower_bound:,.2f} (Q1 - {k}×IQR)")
        else:
            explanations.append("Within standard statistical bounds")
            
    result_df["explanation"] = explanations
    return result_df

def detect_outliers_zscore(df: pd.DataFrame, column: str = "amount", threshold: float = 2.0) -> pd.DataFrame:
    """
    Detect unusual expenses using Z-Score thresholding.
    Formula: Z = (X - mean) / std_dev
    Outlier condition: |Z| > threshold
    """
    if df.empty or column not in df.columns:
        return df

    result_df = df.copy()
    series = result_df[column]
    mean_val = series.mean()
    std_val = series.std()

    if std_val == 0 or np.isnan(std_val):
        result_df["z_score"] = 0.0
        result_df["anomaly_method"] = "Z-Score"
        result_df["is_anomaly"] = False
        result_df["anomaly_status"] = "Normal"
        result_df["explanation"] = "Standard deviation is zero"
        return result_df

    z_scores = (series - mean_val) / std_val
    is_anomaly = z_scores.abs() > threshold

    result_df["z_score"] = z_scores.round(2)
    result_df["anomaly_method"] = "Z-Score"
    result_df["is_anomaly"] = is_anomaly
    result_df["anomaly_status"] = np.where(is_anomaly, "Flagged", "Normal")

    explanations = []
    for z, val in zip(z_scores, series):
        if abs(z) > threshold:
            explanations.append(f"Z-Score = {z:.2f} (|Z| > {threshold} limit, mean=₹{mean_val:,.2f})")
        else:
            explanations.append(f"Normal Z-Score = {z:.2f}")

    result_df["explanation"] = explanations
    return result_df

def detect_outliers_isolation_forest(df: pd.DataFrame, column: str = "amount", contamination: float = 0.05) -> pd.DataFrame:
    """
    Detect unusual expenses using Scikit-Learn Isolation Forest Machine Learning algorithm.
    """
    if df.empty or column not in df.columns or len(df) < 5:
        return df

    result_df = df.copy()
    # Feature matrix: amount + categorical one-hot encoding if category exists
    features = result_df[[column]].values

    iso_forest = IsolationForest(contamination=contamination, random_state=42)
    preds = iso_forest.fit_predict(features) # 1 for inlier, -1 for outlier
    scores = iso_forest.decision_function(features)

    is_anomaly = (preds == -1)
    result_df["anomaly_method"] = "Isolation Forest (ML)"
    result_df["anomaly_score"] = scores.round(3)
    result_df["is_anomaly"] = is_anomaly
    result_df["anomaly_status"] = np.where(is_anomaly, "Flagged", "Normal")

    explanations = []
    for score, is_a in zip(scores, is_anomaly):
        if is_a:
            explanations.append(f"Isolated by ML decision tree forest (Anomaly Score = {score:.3f})")
        else:
            explanations.append(f"Inlier data cluster (Score = {score:.3f})")

    result_df["explanation"] = explanations
    return result_df
