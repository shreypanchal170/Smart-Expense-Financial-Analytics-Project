"""
Statistical Analysis Module for Smart Expense & Financial Analytics System.
Implements Descriptive Statistics and Probabilistic & Inferential Statistics.
Uses NumPy, Pandas, and SciPy.stats.
"""

import pandas as pd
import numpy as np
import scipy.stats as stats
from typing import Dict, Any, Tuple, Optional

def calculate_descriptive_stats(df: pd.DataFrame, column: str = "amount") -> Dict[str, Any]:
    """
    Calculate comprehensive descriptive statistics for a numerical column.
    """
    if df.empty or column not in df.columns:
        return {}

    series = df[column].dropna()
    if series.empty:
        return {}

    mean_val = float(series.mean())
    median_val = float(series.median())
    mode_series = series.mode()
    mode_val = float(mode_series.iloc[0]) if not mode_series.empty else mean_val
    min_val = float(series.min())
    max_val = float(series.max())
    range_val = max_val - min_val
    var_val = float(series.var(ddof=1)) if len(series) > 1 else 0.0
    std_val = float(series.std(ddof=1)) if len(series) > 1 else 0.0

    q1 = float(series.quantile(0.25))
    q3 = float(series.quantile(0.75))
    iqr_val = q3 - q1

    skew_val = float(series.skew()) if len(series) > 2 else 0.0
    kurt_val = float(series.kurtosis()) if len(series) > 3 else 0.0

    return {
        "count": len(series),
        "mean": mean_val,
        "median": median_val,
        "mode": mode_val,
        "min": min_val,
        "max": max_val,
        "range": range_val,
        "variance": var_val,
        "std_dev": std_val,
        "q1": q1,
        "q3": q3,
        "iqr": iqr_val,
        "skewness": skew_val,
        "kurtosis": kurt_val
    }

def get_grouped_descriptive_stats(df: pd.DataFrame, group_col: str = "category", val_col: str = "amount") -> pd.DataFrame:
    """Grouped descriptive statistics table by category or payment method."""
    if df.empty or group_col not in df.columns or val_col not in df.columns:
        return pd.DataFrame()

    grouped = df.groupby(group_col)[val_col].agg(
        Count="count",
        Sum="sum",
        Mean="mean",
        Median="median",
        Std="std",
        Min="min",
        Max="max"
    ).reset_index()

    grouped["IQR"] = df.groupby(group_col)[val_col].apply(lambda x: x.quantile(0.75) - x.quantile(0.25)).values
    grouped = grouped.round(2)
    return grouped.sort_values(by="Sum", ascending=False)

def calculate_confidence_interval(series: pd.Series, confidence: float = 0.95) -> Dict[str, Any]:
    """
    Calculate Confidence Interval for the mean using Student's t-distribution.
    """
    clean_s = series.dropna()
    n = len(clean_s)
    if n < 2:
        return {"mean": 0.0, "ci_lower": 0.0, "ci_upper": 0.0, "margin_error": 0.0, "confidence": confidence}

    mean_val = float(np.mean(clean_s))
    sem = stats.sem(clean_s) # Standard Error of the Mean
    h = sem * stats.t.ppf((1 + confidence) / 2.0, n - 1)

    return {
        "count": n,
        "mean": mean_val,
        "std_err": float(sem),
        "margin_error": float(h),
        "ci_lower": float(mean_val - h),
        "ci_upper": float(mean_val + h),
        "confidence": confidence
    }

def run_one_sample_ttest(series: pd.Series, pop_mean: float = 500.0) -> Dict[str, Any]:
    """
    Perform One-Sample Hypothesis t-test.
    H0: Null Hypothesis - The true mean spending equals pop_mean.
    H1: Alternative Hypothesis - The true mean spending differs from pop_mean.
    """
    clean_s = series.dropna()
    if len(clean_s) < 3:
        return {"error": "Insufficient data points for hypothesis test (n >= 3 required)."}

    t_stat, p_val = stats.ttest_1samp(clean_s, pop_mean)
    sample_mean = float(clean_s.mean())

    alpha = 0.05
    reject_h0 = bool(p_val < alpha)

    interpretation = (
        f"With p-value = {p_val:.4f} < α = {alpha}, we REJECT the null hypothesis (H₀). "
        f"The sample mean (₹{sample_mean:.2f}) differs significantly from the target benchmark of ₹{pop_mean:.2f}."
        if reject_h0 else
        f"With p-value = {p_val:.4f} >= α = {alpha}, we FAIL TO REJECT the null hypothesis (H₀). "
        f"There is no statistically significant difference between sample mean (₹{sample_mean:.2f}) and ₹{pop_mean:.2f}."
    )

    return {
        "sample_size": len(clean_s),
        "sample_mean": sample_mean,
        "target_mean": pop_mean,
        "t_statistic": float(t_stat),
        "p_value": float(p_val),
        "alpha": alpha,
        "reject_h0": reject_h0,
        "interpretation": interpretation
    }

def generate_normal_pdf_fit(series: pd.Series, num_points: int = 100) -> Tuple[np.ndarray, np.ndarray, float, float]:
    """
    Generate Normal Distribution Probability Density Function (PDF) theoretical points
    fitted to empirical expense data parameters (mu, sigma).
    """
    clean_s = series.dropna()
    if clean_s.empty:
        return np.array([]), np.array([]), 0.0, 0.0

    mu = float(clean_s.mean())
    sigma = float(clean_s.std()) if len(clean_s) > 1 else 1.0

    x = np.linspace(clean_s.min(), clean_s.max(), num_points)
    pdf_y = stats.norm.pdf(x, mu, sigma)
    return x, pdf_y, mu, sigma
