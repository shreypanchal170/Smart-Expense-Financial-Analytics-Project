"""
Category Management Module for Smart Expense & Financial Analytics System.
"""

from typing import List, Dict, Any
from database.db_manager import db

DEFAULT_EXPENSE_CATEGORIES = [
    "Food", "Transportation", "Education", "Shopping", "Bills",
    "Healthcare", "Entertainment", "Rent", "Other"
]

DEFAULT_INCOME_SOURCES = [
    "Salary", "Allowance", "Freelance", "Scholarship", "Gift", "Other Income"
]

def get_all_categories(category_type: str = "Expense") -> List[str]:
    """Retrieve category names for a specific category type."""
    query = "SELECT name FROM categories WHERE category_type = ? ORDER BY name ASC"
    rows = db.fetch_all(query, (category_type,))
    if not rows:
        return DEFAULT_EXPENSE_CATEGORIES if category_type == "Expense" else DEFAULT_INCOME_SOURCES
    return [r["name"] for r in rows]

def add_category(name: str, category_type: str = "Expense") -> bool:
    """Add a new custom category."""
    name = name.strip()
    if not name:
        return False
    query = "INSERT OR IGNORE INTO categories (name, category_type) VALUES (?, ?)"
    db.execute_query(query, (name, category_type))
    return True

def delete_category(name: str) -> bool:
    """Delete a category from the system."""
    query = "DELETE FROM categories WHERE name = ?"
    db.execute_query(query, (name,))
    return True
